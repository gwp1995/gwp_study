package com.gree.model

case class Tbl_Assign_Mx(
                      pgmxid:String,
                      created_by:String,
                      created_date:String,
                      last_modified_by:String,
                      last_modified_date:String,
                      pgid:String,
                      spid:String,
                      spmc:String,
                      xlid:String,
                      xlmc:String,
                      xiid:String,
                      ximc:String,
                      jxid:String,
                      jxmc:String,
                      jxno:String,
                      gmsj:String,
                      xsdw:String,
                      xsdwdh:String,
                      fwdw:String,
                      fwdwdh:String,
                      gzwz:String,
                      gzxx:String,
                      czren:String,
                      czsj:String,
                      czwd:String,
                      njtm:String,
                      wjtm:String,
                      beiz:String,
                      njtm2:String,
                      qqlyxh:String,
                      pinpai:String,
                      fee:String,
                      xxfee:String,
                      hsqk:String,
                      gzxxid:String,
                      shul:String,
                      wwsl:String,
                      caozuoType:String,
                      ts:String ,//数据时间戳
                      table: String, //数据来源表名称
                      wxcount:String,//报修次数
                      tmjscount:String,//条码结算次数
                      yblength:String,//延保时长
                      bxdue:String//报修到期
                      )
