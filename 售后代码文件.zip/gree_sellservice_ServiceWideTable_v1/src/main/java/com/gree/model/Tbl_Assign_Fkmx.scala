package com.gree.model

case class Tbl_Assign_Fkmx(
                      fkid:String,
                      created_by:String,
                      created_date:String,
                      last_modified_by:String,
                      last_modified_date:String,
                      pgid:String,
                      fklb:String,
                      fkjg:String,
                      fknr:String,
                      fkren:String,
                      fkrenmc:String,
                      fksj:String,
                      fkwdno:String,
                      fkwdmc:String,
                      scid:String,
                      scwj:String,
                      qqlyxh:String,
                      fkmxguid:String,
                      wjid:String,
                      caozuotypw:String,
                      ts:String ,//数据时间戳
                      table: String //数据来源表名称
                      )


