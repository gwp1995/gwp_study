package com.gree.util

import java.net.InetAddress

import com.gree.constant.Constant
import org.elasticsearch.client.transport.TransportClient
import org.elasticsearch.common.settings.Settings
import org.elasticsearch.common.transport.TransportAddress
import org.elasticsearch.transport.client.PreBuiltTransportClient
import org.slf4j.{Logger, LoggerFactory}

object EsConnection {

  val logger: Logger = LoggerFactory.getLogger(EsConnection.super.getClass)
  def createESConnection():TransportClient = {
    val settings: Settings = Settings.builder()
      .put("cluster.name",  Constant.CLUSTER_NAME)
      .build()

    //连接ES
    val client: TransportClient = new PreBuiltTransportClient(settings)
      .addTransportAddresses(
        new TransportAddress(InetAddress.getByName("10.2.13.100"), 9300),
        new TransportAddress(InetAddress.getByName("10.2.13.101"), 9300),
        new TransportAddress(InetAddress.getByName("10.2.13.102"), 9300)
      )
    client
  }

  val conn:TransportClient = createESConnection()

  Runtime.getRuntime.addShutdownHook(new Thread(){
    override def run(): Unit = {
      logger.info("close")
      conn.close()
    }
  })

}
