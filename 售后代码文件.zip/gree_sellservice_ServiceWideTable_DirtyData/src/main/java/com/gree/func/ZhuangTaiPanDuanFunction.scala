package com.gree.func

import com.gree.model.{DirtyData, Tbl_Assign_Model, TrueData}
import com.gree.util.EsConnection
import org.apache.flink.streaming.api.functions.ProcessFunction
import org.apache.flink.streaming.api.scala.OutputTag
import org.apache.flink.util.Collector
import org.elasticsearch.action.search.SearchResponse
import org.elasticsearch.client.transport.TransportClient
import org.elasticsearch.index.query.QueryBuilders
import org.elasticsearch.search.SearchHits
import org.slf4j.{Logger, LoggerFactory}
import scala.util.control.Breaks._

class ZhuangTaiPanDuanFunction(zangshuju:OutputTag[DirtyData])  extends  ProcessFunction[Tbl_Assign_Model,DirtyData]{
  override def processElement(value: Tbl_Assign_Model, ctx: ProcessFunction[Tbl_Assign_Model, DirtyData]#Context, out: Collector[DirtyData]): Unit = {
    // 建立ES连接
    val client: TransportClient = EsConnection.conn
    val logger: Logger = LoggerFactory.getLogger(ZhuangTaiPanDuanFunction.super.getClass)
    //根据流数据返查es进行判断,查找是否存在同一个主键id。
    var describe:String = "null"
    var gethits:Long = 0
    var state:Long = 0
    var count:Long = 6
    try {
      breakable{
        while (count >0){
          logger.info("索引名称:"+value.index+"查询主键id名称："+ value.query_name +"查询主键id值："+ value.id + "数据来源表名："+ value.table)
          //如果在es中找不到对应id的值，则说明数据同步到es发生了丢数据
          val zhuangtai:SearchResponse = client
            .prepareSearch(value.index)
            .setTypes("_doc")
            .setQuery(QueryBuilders.boolQuery().must(QueryBuilders.termQuery(value.query_name, value.id))
              .must(QueryBuilders.rangeQuery("ts").gte(value.ts)))
            .get()
          gethits = zhuangtai.getHits.totalHits
          logger.info("主键id查询出的记录数：=>" + zhuangtai.getHits.totalHits)

          if (gethits > 0){ break() }
          Thread.sleep(200)
          count = count - 1
        }
      }
      //判断流数据能否从主表es查询出数据，能则进入主流，否则进入侧输出流
      if (gethits > 0) {
        describe = "数据正常延时，此条数据无需手动处理，已自动补回"
        out.collect(DirtyData(value.id,value.pgid,value.table,value.ts,state,describe))
      } else {
        state = 1
        describe = "数据延时过长或者丢失，此条数据需手动处理、补回"
        ctx.output(zangshuju,DirtyData(value.id,value.pgid,value.table,value.ts,state,describe))
      }
    } catch {
      case e: Exception => logger.info("状态判断表状态判断函数异常：" + e.getMessage)
    }
  }
}
