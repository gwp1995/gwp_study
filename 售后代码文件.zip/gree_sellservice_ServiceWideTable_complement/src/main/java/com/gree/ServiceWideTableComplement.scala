package com.gree



import java.util

import com.google.gson.Gson
import com.gree.constant.Constant
import com.gree.func.KafkaOutputFormat
import com.gree.model._
import com.gree.newfun._
import org.apache.flink.api.common.typeinfo.{BasicTypeInfo, SqlTimeTypeInfo}
import org.apache.flink.api.java.io.jdbc.{JDBCInputFormat, JDBCOutputFormat}
import org.apache.flink.api.java.typeutils.RowTypeInfo
import org.apache.flink.api.scala.ExecutionEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.table.api.scala.BatchTableEnvironment
import org.apache.flink.table.api.{Table, TableEnvironment, Types}
import org.apache.flink.types.Row
import com.gree.util.{JsonBeanUtil, NumberFormatUtil}
import org.apache.flink.api.common.functions.RuntimeContext
import org.apache.http.HttpHost
import org.elasticsearch.action.DocWriteRequest
import org.elasticsearch.action.index.IndexRequest
import org.elasticsearch.client.{Requests, RestClientBuilder}
import org.json4s.{Formats, NoTypeHints}

import scala.collection.JavaConversions._








object ServiceWideTableComplement {

  def main(args: Array[String]): Unit = {
    //获取批处理执行环境
    val env = ExecutionEnvironment.getExecutionEnvironment
    val table = BatchTableEnvironment.create(env)
//    val tableEnv = BatchTableEnvironment.create(env)
    //调用自己封装的工具类
    val utiltest = new NumberFormatUtil


     val readdata = env.createInput(
      JDBCInputFormat.buildJDBCInputFormat()
        .setDrivername(Constant.JDBC_DRIVENAME)
        .setDBUrl(Constant.TIDB_URL)
        .setUsername(Constant.TIDB_USER)
        .setPassword(Constant.TIDB_PASSWORD)
        .setQuery("select id,pgid,tablename,ts,state,data_describe from service_dirtydata where state <2 ")
        .setRowTypeInfo(new RowTypeInfo(BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO
          , BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.INT_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO))
        .setFetchSize(1)
        .finish()
    )

//    readdata.print()
      //将读取数据进行动态sql拼装
    val list1 = readdata.map(x => (x.getField(2),x.getField(0))).collect()
    var sql_zhubiao:String = "select * from tbl_assign where pgid in ("
    var sql_fkmx:String = "select * from tbl_assign_fkmx where fkid in ("
    var sql_appointment:String = "select * from tbl_assign_appointment where id in ("
    var sql_mx:String = "select * from tbl_assign_mx where pgmxid in ("
    var sql_daijian:String = "select * from tbl_assign_daijian where id in ("
    var sql_feedback:String = "select * from tbl_assign_feedback where id in ("
    var sql_satisfaction:String = "select * from tbl_assign_satisfaction where id in ("
    var sql_xzyd:String = "select * from tbl_assign_xzyd where xzid in ("
    //根据表名初始化多个列表，为后续拼接动态sql做准备
    val list_zhubiao = new java.util.ArrayList[Any]
    val list_fkmx = new java.util.ArrayList[Any]
    val list_appointment = new java.util.ArrayList[Any]
    val list_mx = new java.util.ArrayList[Any]
    val list_daijian = new java.util.ArrayList[Any]
    val list_feedback = new java.util.ArrayList[Any]
    val list_satisfaction = new java.util.ArrayList[Any]
    val list_xzyd = new java.util.ArrayList[Any]
    val list_other = new java.util.ArrayList[(Any,Any)]
    //原始查询数据按照表名拆分成多个列表
    for (ll <- list1){
      if ("tbl_assign".equals(ll._1)){ list_zhubiao.add(ll._2) }
      else if ("tbl_assign_fkmx".equals(ll._1)){ list_fkmx.add(ll._2) }
      else if ("tbl_assign_appointment".equals(ll._1)){ list_appointment.add(ll._2) }
      else if ("tbl_assign_mx".equals(ll._1)){ list_mx.add(ll._2) }
      else if ("tbl_assign_daijian".equals(ll._1)){ list_daijian.add(ll._2) }
      else if ("tbl_assign_feedback".equals(ll._1)){ list_feedback.add(ll._2) }
      else if ("tbl_assign_satisfaction".equals(ll._1)){ list_satisfaction.add(ll._2) }
      else if ("tbl_assign_xzyd".equals(ll._1)){ list_xzyd.add(ll._2) }
      else{ list_other.add((ll._1,ll._2)) }
    }

    // 拼接主表查询sql
    var j = 0
    for (list <- list_zhubiao){
      sql_zhubiao += list
      j += 1
      if (j < list_zhubiao.length){ sql_zhubiao += "," }else{ sql_zhubiao += ")" }
    }
//    println("打印拼接好的主表信息："+sql_zhubiao)
    //拼接预约表查询sql
    var t = 0
    for (list <- list_appointment){
      sql_appointment += " '" + list + " '"
      t += 1
      if (t < list_appointment.length){ sql_appointment += "," }else{ sql_appointment += ")" }
    }
//    println("打印拼接好的预约表信息："+sql_appointment)
    //拼接反馈明细表查询sql
    var b = 0
    for (list <- list_fkmx){
      sql_fkmx += list
      b += 1
      if (b < list_fkmx.length ){ sql_fkmx += "," }else{ sql_fkmx += ")" }
    }
//    println("打印拼接好的fkmx信息："+sql_fkmx)
    //拼接明细表查询sql
    var a = 0
    for (list <- list_mx){
      sql_mx += list
      a += 1
      if (a < list_mx.length){ sql_mx += "," }else{ sql_mx += ")" }
    }
//    println("打印拼接好的mx表信息："+sql_mx)
    //拼接待件表查询sql
    var c = 0
    for (list <- list_daijian){
      sql_daijian += " '" + list + " '"
      c += 1
      if (c < list_daijian.length){ sql_daijian += "," }else{ sql_daijian += ")" }
    }
//    println("打印拼接好的daijian表信息："+sql_daijian)
    //拼接反馈表查询sql
    var d = 0
    for (list <- list_feedback){
      sql_feedback += list
      d += 1
      if (d < list_feedback.length){ sql_feedback += "," }else{ sql_feedback += ")" }
    }
//    println("打印拼接好的feedback信息："+sql_feedback)
    //拼接满意度表查询sql
    var e = 0
    for (list <- list_satisfaction){
      sql_satisfaction += list
      e += 1
      if (e < list_satisfaction.length){ sql_satisfaction += "," }else{ sql_satisfaction += ")" }
    }
//    println("打印拼接好的satisfaction信息："+sql_satisfaction)
    //拼接新增信息表查询sql
    var i = 0
    for (list <- list_xzyd){
      sql_xzyd += list
      i += 1
      if (i < list_xzyd.length){ sql_xzyd }else{ sql_xzyd += ")" }
    }
//    println("打印拼接好的xzyd表信息："+sql_xzyd)


    //es配置信息
    val httplist = new java.util.ArrayList[HttpHost]()
    httplist.add(new HttpHost(Constant.ES_HOST100,Constant.ES_HTTP_PORT,Constant.ES_SCHEME))
    httplist.add(new HttpHost(Constant.ES_HOST101,Constant.ES_HTTP_PORT,Constant.ES_SCHEME))
    httplist.add(new HttpHost(Constant.ES_HOST102,Constant.ES_HTTP_PORT,Constant.ES_SCHEME))
    val config = new java.util.HashMap[String,String]()
    config.put("bulk.flush.max.action","1")
    config.put("bulk.flush.max.size.mb","10")
    config.put("bulk.flush.interval.ms","10")
    //模拟抓取云上主表数据
    if (list_zhubiao.nonEmpty) {
      val zhubiao:DataSet[Row] = env.createInput(
        JDBCInputFormat.buildJDBCInputFormat()
          .setDrivername(Constant.JDBC_DRIVENAME)
          .setDBUrl(Constant.YUN_URL)
          .setUsername(Constant.YUN_USER)
          .setPassword(Constant.YUN_PASSWORD)
          .setQuery(sql_zhubiao)
          .setRowTypeInfo(new RowTypeInfo(
            BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO, SqlTimeTypeInfo.TIMESTAMP,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP, BasicTypeInfo.LONG_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO,
            SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.LONG_TYPE_INFO, SqlTimeTypeInfo.TIMESTAMP,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.INT_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP, BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO, SqlTimeTypeInfo.TIMESTAMP,
            SqlTimeTypeInfo.TIMESTAMP,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.INT_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,
            BasicTypeInfo.INT_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.INT_TYPE_INFO,BasicTypeInfo.INT_TYPE_INFO,
            SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.INT_TYPE_INFO,BasicTypeInfo.INT_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.LONG_TYPE_INFO,
            BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO
          ))
          .setFetchSize(1)
          .finish()
      )
      //表关联抓取时间戳字段
      val result_zhubiao = readdata.join(zhubiao).where(0).equalTo(_.getField(0).toString)
      //row类型转换成实体类
      val zhubiaotest:DataSet[Tbl_Assign] = result_zhubiao.map{
        x =>
          Tbl_Assign(
            utiltest.panduanNullnew(x._2.getField(0)),utiltest.panduanNullnew(x._2.getField(1)),utiltest.panduantimeNull(x._2.getField(2)),
            utiltest.panduanNullnew(x._2.getField(3)),utiltest.panduantimeNull(x._2.getField(4)),utiltest.panduanNullnew(x._2.getField(5)),
            utiltest.panduanNullnew(x._2.getField(6)),utiltest.panduanNullnew(x._2.getField(7)),utiltest.panduanNullnew(x._2.getField(8)),
            utiltest.panduanNullnew(x._2.getField(9)),utiltest.panduanNullnew(x._2.getField(10)),utiltest.panduanNullnew(x._2.getField(11)),
            utiltest.panduanNullnew(x._2.getField(12)),utiltest.panduanNullnew(x._2.getField(13)),utiltest.panduanNullnew(x._2.getField(14)),
            utiltest.panduanNullnew(x._2.getField(15)),utiltest.panduanNullnew(x._2.getField(16)),utiltest.panduanNullnew(x._2.getField(17)),
            utiltest.panduanNullnew(x._2.getField(18)),utiltest.panduanNullnew(x._2.getField(19)),utiltest.panduanNullnew(x._2.getField(20)),
            utiltest.panduanNullnew(x._2.getField(21)),utiltest.panduanNullnew(x._2.getField(22)),utiltest.panduantimeNull(x._2.getField(23)),
            utiltest.panduanNullnew(x._2.getField(24)),utiltest.panduanNullnew(x._2.getField(25)),utiltest.panduanNullnew(x._2.getField(26)),
            utiltest.panduanNullnew(x._2.getField(27)),utiltest.panduanNullnew(x._2.getField(28)),utiltest.panduanNullnew(x._2.getField(29)),
            utiltest.panduantimeNull(x._2.getField(30)),utiltest.panduanNullnew(x._2.getField(31)),utiltest.panduanNullnew(x._2.getField(32)),
            utiltest.panduanNullnew(x._2.getField(33)),utiltest.panduantimeNull(x._2.getField(34)),utiltest.panduanNullnew(x._2.getField(35)),
            utiltest.panduanNullnew(x._2.getField(36)),utiltest.panduanNullnew(x._2.getField(37)),utiltest.panduanNullnew(x._2.getField(38)),
            utiltest.panduanNullnew(x._2.getField(39)),utiltest.panduanNullnew(x._2.getField(40)),utiltest.panduanNullnew(x._2.getField(41)),
            utiltest.panduanNullnew(x._2.getField(42)),utiltest.panduanNullnew(x._2.getField(43)),utiltest.panduanNullnew(x._2.getField(44)),
            utiltest.panduanNullnew(x._2.getField(45)),utiltest.panduanNullnew(x._2.getField(46)),utiltest.panduanNullnew(x._2.getField(47)),
            utiltest.panduantimeNull(x._2.getField(48)),utiltest.panduanNullnew(x._2.getField(49)),utiltest.panduanNullnew(x._2.getField(50)),
            utiltest.panduanNullnew(x._2.getField(51)),utiltest.panduanNullnew(x._2.getField(52)),utiltest.panduanNullnew(x._2.getField(53)),
            utiltest.panduantimeNull(x._2.getField(54)),utiltest.panduantimeNull(x._2.getField(55)),utiltest.panduantimeNull(x._2.getField(56)),
            utiltest.panduanNullnew(x._2.getField(57)),utiltest.panduanNullnew(x._2.getField(58)),utiltest.panduanNullnew(x._2.getField(59)),
            utiltest.panduanNullnew(x._2.getField(60)),utiltest.panduanNullnew(x._2.getField(61)),utiltest.panduanNullnew(x._2.getField(62)),
            utiltest.panduanNullnew(x._2.getField(63)),utiltest.panduantimeNull(x._2.getField(64)),utiltest.panduanNullnew(x._2.getField(65)),
            utiltest.panduanNullnew(x._2.getField(66)),utiltest.panduanNullnew(x._2.getField(67)),utiltest.panduanNullnew(x._2.getField(68)),
            utiltest.panduanNullnew(x._2.getField(69)),utiltest.panduantimeNull(x._2.getField(70)),utiltest.panduanNullnew(x._2.getField(71)),
            utiltest.panduanNullnew(x._2.getField(72)),utiltest.panduanNullnew(x._2.getField(73)),utiltest.panduanNullnew(x._2.getField(74)),
            utiltest.panduanNullnew(x._2.getField(75)),utiltest.panduanNullnew(x._2.getField(76)),utiltest.panduanNullnew(x._2.getField(77)),
            utiltest.panduanNullnew(x._2.getField(78)),utiltest.panduanNullnew(x._2.getField(79)),utiltest.panduanNullnew(x._2.getField(80)),
            utiltest.panduanNullnew(x._2.getField(81)),utiltest.panduanNullnew(x._2.getField(82)),utiltest.panduanNullnew(x._2.getField(83)),
            utiltest.panduanNullnew(x._2.getField(84)),utiltest.panduanNullnew(x._2.getField(85)),utiltest.panduanNullnew(x._2.getField(86)),
            utiltest.panduanNullnew(x._2.getField(87)),utiltest.panduanNullnew(x._2.getField(88)),utiltest.panduanNullnew(x._2.getField(89)),
            utiltest.panduanNullnew(x._2.getField(90)),utiltest.panduanNullnew(x._1.getField(3))

          )
      }
      zhubiaotest.print()
      //数据写入es主表中
      val elasticsearchSinkFunction_zhubiao = new ElasticsearchSinkFunction[Tbl_Assign] {
        def  createIndexRequest(element: Tbl_Assign):IndexRequest = {
          val json = JsonBeanUtil.getTblAssignJson(element)
          println("测试转换后的json数据："+json)
          Requests.indexRequest.index(Constant.TBL_ASSIGN_INDEX)
            .`type`(Constant.ES_TYPE)
            .id(element.pgid)
            .source(json)
        }
        override def process(element: Tbl_Assign, ctx: RuntimeContext, indexer: RequestIndexer): Unit = {
          indexer.add(createIndexRequest(element))
        }
      }
      val outputFormat = new ElasticsearchOutputFormat.Builder[Tbl_Assign](
        httplist,config,elasticsearchSinkFunction_zhubiao)
        .build()

      zhubiaotest.output(outputFormat)
    }

    //模拟从云上数据库抓取需要的fkmx表数据
    if (list_fkmx.nonEmpty){
      val fkmx:DataSet[Row] = env.createInput(
        JDBCInputFormat.buildJDBCInputFormat()
          .setDrivername(Constant.JDBC_DRIVENAME)
          .setDBUrl(Constant.YUN_URL)
          .setUsername(Constant.YUN_USER)
          .setPassword(Constant.YUN_PASSWORD)
          .setQuery(sql_fkmx)
          .setRowTypeInfo(new RowTypeInfo(
            BasicTypeInfo.LONG_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,  BasicTypeInfo.STRING_TYPE_INFO
            ,SqlTimeTypeInfo.TIMESTAMP, BasicTypeInfo.LONG_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO
            ,BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO, SqlTimeTypeInfo.TIMESTAMP
            ,BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO
            ,BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO, BasicTypeInfo.STRING_TYPE_INFO
          )
          )
          .setFetchSize(1)
          .finish()
      )
      //表关联抓取数据的ts字段
      val result_fkmx = readdata.join(fkmx).where(0).equalTo(_.getField(0).toString)
      //ROW型数据转成实体类--fkmx表
      val fkmxtest:DataSet[Tbl_Assign_Fkmx] = result_fkmx.map{
        x => Tbl_Assign_Fkmx(
          utiltest.panduanNullnew(x._2.getField(0)),utiltest.panduanNullnew(x._2.getField(1)),utiltest.panduantimeNull(x._2.getField(2)),
          utiltest.panduanNullnew(x._2.getField(3)), utiltest.panduantimeNull(x._2.getField(4)),utiltest.panduanNullnew(x._2.getField(5)),
          utiltest.panduanNullnew(x._2.getField(6)),utiltest.panduanNullnew(x._2.getField(7)), utiltest.panduanNullnew(x._2.getField(8)),
          utiltest.panduanNullnew(x._2.getField(9)), utiltest.panduanNullnew(x._2.getField(10)),utiltest.panduantimeNull(x._2.getField(11)),
          utiltest.panduanNullnew(x._2.getField(12)),utiltest.panduanNullnew(x._2.getField(13)), utiltest.panduanNullnew(x._2.getField(14)),
          utiltest.panduanNullnew(x._2.getField(15)),utiltest.panduanNullnew(x._2.getField(16)), utiltest.panduanNullnew(x._2.getField(17)),
          utiltest.panduanNullnew(x._2.getField(18)),utiltest.panduanNullnew(x._1.getField(3)))
      }
      fkmxtest.print()
     //fkmx数据写入es中
      val elasticsearchSinkFunction_fkmx = new ElasticsearchSinkFunction[Tbl_Assign_Fkmx] {
        def  createIndexRequest(element: Tbl_Assign_Fkmx):IndexRequest = {
          val json = JsonBeanUtil.getfkmxJson(element)
          println("测试转换后的json数据："+json)
          Requests.indexRequest.index(Constant.TBL_ASSIGN_FKMX_INDEX)
            .`type`(Constant.ES_TYPE)
            .id(element.fkid)
            .source(json)
        }
        override def process(element: Tbl_Assign_Fkmx, ctx: RuntimeContext, indexer: RequestIndexer): Unit = {
          indexer.add(createIndexRequest(element))
        }
      }
      val outputFormat = new ElasticsearchOutputFormat.Builder[Tbl_Assign_Fkmx](
        httplist,config,elasticsearchSinkFunction_fkmx)
        .build()

          fkmxtest.output(outputFormat)
    }

    //模拟从云上数据库抓取需要的预约表数据
    if (list_appointment.nonEmpty){
//      println("进入预约表补数逻辑分支")
      val appointment:DataSet[Row] = env.createInput(
        JDBCInputFormat.buildJDBCInputFormat()
          .setDrivername(Constant.JDBC_DRIVENAME)
          .setDBUrl(Constant.YUN_URL)
          .setUsername(Constant.YUN_USER)
          .setPassword(Constant.YUN_PASSWORD)
          .setQuery(sql_appointment)
          .setRowTypeInfo(new RowTypeInfo(
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO,
            SqlTimeTypeInfo.TIMESTAMP,SqlTimeTypeInfo.TIMESTAMP,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.LONG_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO ) )
          .setFetchSize(1)
          .finish()
      )
      //关联抓取时间ts字段
      val result_appoinment = readdata.join(appointment).where(0).equalTo(_.getField(0).toString)
      //将ROW类型转换成实体类
      val appointmenttest:DataSet[Tbl_Assign_Appointment] = result_appoinment.map{
        x => Tbl_Assign_Appointment(
          utiltest.panduanNullnew(x._2.getField(0)),utiltest.panduanNullnew(x._2.getField(1)),utiltest.panduantimeNull(x._2.getField(2)),
          utiltest.panduanNullnew(x._2.getField(3)),utiltest.panduantimeNull(x._2.getField(4)),utiltest.panduantimeNull(x._2.getField(5)),
          utiltest.panduantimeNull(x._2.getField(6)),utiltest.panduanNullnew(x._2.getField(7)),utiltest.panduanNullnew(x._2.getField(8)),
          utiltest.panduantimeNull(x._2.getField(9)),utiltest.panduanNullnew(x._2.getField(10)),utiltest.panduanNullnew(x._2.getField(11)),
          utiltest.panduanNullnew(x._2.getField(12)),utiltest.panduanNullnew(x._1.getField(3))
        )
      }
      appointmenttest.print()
      //数据写入es预约表中
      val elasticsearchSinkFunction_appointment = new ElasticsearchSinkFunction[Tbl_Assign_Appointment] {
        def  createIndexRequest(element: Tbl_Assign_Appointment):IndexRequest = {
          val json = JsonBeanUtil.getTblAssignAppointmentJson(element)
          println("测试转换后的json数据："+json)
          Requests.indexRequest.index(Constant.TBL_ASSIGN_APPOINTMENT_INDEX)
            .`type`(Constant.ES_TYPE)
            .id(element.id)
            .source(json)
        }
        override def process(element: Tbl_Assign_Appointment, ctx: RuntimeContext, indexer: RequestIndexer): Unit = {
          indexer.add(createIndexRequest(element))
        }
      }
      val outputFormat = new ElasticsearchOutputFormat.Builder[Tbl_Assign_Appointment](
        httplist,config,elasticsearchSinkFunction_appointment)
        .build()

      appointmenttest.output(outputFormat)
    }

    //模拟从云上抓取需要的明细表数据
    if (list_mx.nonEmpty){
      val mx:DataSet[Row] = env.createInput(
        JDBCInputFormat.buildJDBCInputFormat()
          .setDrivername(Constant.JDBC_DRIVENAME)
          .setDBUrl(Constant.YUN_URL)
          .setUsername(Constant.YUN_USER)
          .setPassword(Constant.YUN_PASSWORD)
          .setQuery(sql_mx)
          .setRowTypeInfo(new RowTypeInfo(
            BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO,
            SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.INT_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.BIG_DEC_TYPE_INFO,
            BasicTypeInfo.BIG_DEC_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.INT_TYPE_INFO,
            BasicTypeInfo.INT_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.INT_TYPE_INFO,BasicTypeInfo.BIG_DEC_TYPE_INFO,
            SqlTimeTypeInfo.TIMESTAMP ))
          .setFetchSize(1)
          .finish()
      )
      //关联抓取时间ts字段
      val result_mx = readdata.join(mx).where(0).equalTo(_.getField(0).toString)
//      result_mx.print()
      //row类型转换成实体类
      val mxtest:DataSet[Tbl_Assign_Mx] = result_mx.map{
        x => Tbl_Assign_Mx(
          utiltest.panduanNullnew(x._2.getField(0)),utiltest.panduanNullnew(x._2.getField(1)),utiltest.panduantimeNull(x._2.getField(2)),
          utiltest.panduanNullnew(x._2.getField(3)),utiltest.panduantimeNull(x._2.getField(4)),utiltest.panduanNullnew(x._2.getField(5)),
          utiltest.panduanNullnew(x._2.getField(6)),utiltest.panduanNullnew(x._2.getField(7)),utiltest.panduanNullnew(x._2.getField(8)),
          utiltest.panduanNullnew(x._2.getField(9)),utiltest.panduanNullnew(x._2.getField(10)),utiltest.panduanNullnew(x._2.getField(11)),
          utiltest.panduanNullnew(x._2.getField(12)),utiltest.panduanNullnew(x._2.getField(13)),utiltest.panduanNullnew(x._2.getField(14)),
          utiltest.panduantimeNull(x._2.getField(15)),utiltest.panduanNullnew(x._2.getField(16)),utiltest.panduanNullnew(x._2.getField(17)),
          utiltest.panduanNullnew(x._2.getField(18)),utiltest.panduanNullnew(x._2.getField(19)),utiltest.panduanNullnew(x._2.getField(20)),
          utiltest.panduanNullnew(x._2.getField(21)),utiltest.panduanNullnew(x._2.getField(22)),utiltest.panduantimeNull(x._2.getField(23)),
          utiltest.panduanNullnew(x._2.getField(24)),utiltest.panduanNullnew(x._2.getField(25)),utiltest.panduanNullnew(x._2.getField(26)),
          utiltest.panduanNullnew(x._2.getField(27)),utiltest.panduanNullnew(x._2.getField(28)),utiltest.panduanNullnew(x._2.getField(29)),
          utiltest.panduanNullnew(x._2.getField(30)),utiltest.panduanNullnew(x._2.getField(31)),utiltest.panduanNullnew(x._2.getField(32)),
          utiltest.panduanNullnew(x._2.getField(33)),utiltest.panduanNullnew(x._2.getField(34)),utiltest.panduanNullnew(x._2.getField(35)),
          utiltest.panduanNullnew(x._2.getField(36)),utiltest.panduanNullnew(x._2.getField(37)),utiltest.panduanNullnew(x._2.getField(38)),
          utiltest.panduanNullnew(x._2.getField(39)),utiltest.panduantimeNull(x._2.getField(40)),utiltest.panduanNullnew(x._1.getField(3))
        )
      }
//      mxtest.print()
      //数据写入es明细表
      val elasticsearchSinkFunction_mx = new ElasticsearchSinkFunction[Tbl_Assign_Mx] {
        def  createIndexRequest(element: Tbl_Assign_Mx):IndexRequest = {
          val json = JsonBeanUtil.getTblAssignMx(element)
//          println("测试转换后的json数据："+json)
          Requests.indexRequest.index(Constant.TBL_ASSIGN_MX_INDEX)
            .`type`(Constant.ES_TYPE)
            .id(element.pgmxid)
            .source(json)
        }
        override def process(element: Tbl_Assign_Mx, ctx: RuntimeContext, indexer: RequestIndexer): Unit = {
          indexer.add(createIndexRequest(element))
        }
      }
      val outputFormat = new ElasticsearchOutputFormat.Builder[Tbl_Assign_Mx](
        httplist,config,elasticsearchSinkFunction_mx)
        .build()
      mxtest.output(outputFormat)

    }

    //模拟从云上抓取需要的待件数据
    if (list_daijian.nonEmpty){
       val daijian:DataSet[Row] = env.createInput(
         JDBCInputFormat.buildJDBCInputFormat()
           .setDrivername(Constant.JDBC_DRIVENAME)
           .setDBUrl(Constant.YUN_URL)
           .setUsername(Constant.YUN_USER)
           .setPassword(Constant.YUN_PASSWORD)
           .setQuery(sql_daijian)
           .setRowTypeInfo(new RowTypeInfo(
             BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO,
             SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,SqlTimeTypeInfo.TIMESTAMP,
             SqlTimeTypeInfo.TIMESTAMP,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.INT_TYPE_INFO,BasicTypeInfo.INT_TYPE_INFO,
             BasicTypeInfo.INT_TYPE_INFO,BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,
             SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.INT_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO,
             BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.INT_TYPE_INFO,BasicTypeInfo.INT_TYPE_INFO,BasicTypeInfo.INT_TYPE_INFO,
             BasicTypeInfo.INT_TYPE_INFO
           ))
           .setFetchSize(1)
           .finish()
       )
      //关联抓取时间ts
      val result_daijian = readdata.join(daijian).where(0).equalTo(_.getField(0).toString)
//      result_daijian.print()
      //转换实体类
      val daijiantest:DataSet[Tbl_Assign_DaiJian] = result_daijian.map{
        x => Tbl_Assign_DaiJian(
          utiltest.panduanNullnew(x._2.getField(0)),utiltest.panduanNullnew(x._2.getField(1)),utiltest.panduantimeNull(x._2.getField(2)),
          utiltest.panduanNullnew(x._2.getField(3)),utiltest.panduantimeNull(x._2.getField(4)),utiltest.panduanNullnew(x._2.getField(5)),
          utiltest.panduantimeNull(x._2.getField(6)),utiltest.panduanNullnew(x._2.getField(7)),utiltest.panduanNullnew(x._2.getField(8)),
          utiltest.panduanNullnew(x._2.getField(9)),utiltest.panduanNullnew(x._2.getField(10)),utiltest.panduanNullnew(x._2.getField(11)),
          utiltest.panduanNullnew(x._2.getField(12)),utiltest.panduanNullnew(x._2.getField(13)),utiltest.panduanNullnew(x._2.getField(14)),
          utiltest.panduanNullnew(x._2.getField(15)),utiltest.panduantimeNull(x._2.getField(16)),utiltest.panduanNullnew(x._2.getField(17)),
          utiltest.panduantimeNull(x._2.getField(18)),utiltest.panduanNullnew(x._2.getField(19)),utiltest.panduanNullnew(x._2.getField(20)),
          utiltest.panduanNullnew(x._2.getField(21)),utiltest.panduanNullnew(x._2.getField(22)),utiltest.panduanNullnew(x._2.getField(23)),
          utiltest.panduanNullnew(x._2.getField(24)),utiltest.panduanNullnew(x._1.getField(3))
        )
      }
//      daijiantest.print()
      //数据写入es待件表
      val elasticsearchSinkFunction_daijian = new ElasticsearchSinkFunction[Tbl_Assign_DaiJian] {
        def  createIndexRequest(element: Tbl_Assign_DaiJian):IndexRequest = {
          val json = JsonBeanUtil.getTblAssignDaijian(element)
          //          println("测试转换后的json数据："+json)
          Requests.indexRequest.index(Constant.TBL_ASSIGN_DAIJIAN_INDEX)
            .`type`(Constant.ES_TYPE)
            .id(element.id)
            .source(json)
        }
        override def process(element: Tbl_Assign_DaiJian, ctx: RuntimeContext, indexer: RequestIndexer): Unit = {
          indexer.add(createIndexRequest(element))
        }
      }
      val outputFormat = new ElasticsearchOutputFormat.Builder[Tbl_Assign_DaiJian](
        httplist,config,elasticsearchSinkFunction_daijian)
        .build()
      daijiantest.output(outputFormat)
    }

    //模拟从云上抓取需要的反馈数据
    if (list_feedback.nonEmpty){
      val feedBack:DataSet[Row] = env.createInput(
        JDBCInputFormat.buildJDBCInputFormat()
          .setDrivername(Constant.JDBC_DRIVENAME)
          .setDBUrl(Constant.YUN_URL)
          .setUsername(Constant.YUN_USER)
          .setPassword(Constant.YUN_PASSWORD)
          .setQuery(sql_daijian)
          .setRowTypeInfo(new RowTypeInfo(
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO,
            SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.LONG_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP
          ))
          .setFetchSize(1)
          .finish()
      )
      //关联抓取时间ts
      val result_feedback = readdata.join(feedBack).where(0).equalTo(_.getField(0).toString)
      //转换成实体类
      val feedBacktest:DataSet[Tbl_Assign_FeedBack] = result_feedback.map{
        x => Tbl_Assign_FeedBack(
          utiltest.panduanNullnew(x._2.getField(0)),utiltest.panduanNullnew(x._2.getField(1)),utiltest.panduantimeNull(x._2.getField(2)),
          utiltest.panduanNullnew(x._2.getField(3)),utiltest.panduantimeNull(x._2.getField(4)),utiltest.panduanNullnew(x._2.getField(5)),
          utiltest.panduantimeNull(x._2.getField(6)),utiltest.panduanNullnew(x._2.getField(7)),utiltest.panduanNullnew(x._2.getField(8)),
          utiltest.panduantimeNull(x._2.getField(9)),utiltest.panduanNullnew(x._1.getField(3))
        )
      }
      //输出到es反馈表中
      val elasticsearchSinkFunction_feedback = new ElasticsearchSinkFunction[Tbl_Assign_FeedBack] {
        def  createIndexRequest(element: Tbl_Assign_FeedBack):IndexRequest = {
          val json = JsonBeanUtil.getTblAssignFeedBack(element)
          //          println("测试转换后的json数据："+json)
          Requests.indexRequest.index(Constant.TBL_ASSIGN_FEEDBACK_INDEX)
            .`type`(Constant.ES_TYPE)
            .id(element.id)
            .source(json)
        }
        override def process(element: Tbl_Assign_FeedBack, ctx: RuntimeContext, indexer: RequestIndexer): Unit = {
          indexer.add(createIndexRequest(element))
        }
      }
      val outputFormat = new ElasticsearchOutputFormat.Builder[Tbl_Assign_FeedBack](
        httplist,config,elasticsearchSinkFunction_feedback)
        .build()
      feedBacktest.output(outputFormat)
    }

    //模拟从云上抓取需要的满意度数据
    if (list_satisfaction.nonEmpty){
       val satisfaction:DataSet[Row] = env.createInput(
         JDBCInputFormat.buildJDBCInputFormat()
           .setDrivername(Constant.JDBC_DRIVENAME)
           .setDBUrl(Constant.YUN_URL)
           .setUsername(Constant.YUN_USER)
           .setPassword(Constant.YUN_PASSWORD)
           .setQuery(sql_satisfaction)
           .setRowTypeInfo(new RowTypeInfo(
            BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO,
             SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,
             BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,
             BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.LONG_TYPE_INFO,
             BasicTypeInfo.INT_TYPE_INFO,BasicTypeInfo.INT_TYPE_INFO
           ))
           .setFetchSize(1)
           .finish()
       )
      //关联抓取时间ts
      val result_satisfaction = readdata.join(satisfaction).where(0).equalTo(_.getField(0).toString)
      //row转实体类型
      val satisfactiontest:DataSet[Tbl_Assign_Satisfaction] = result_satisfaction.map{
        x =>  Tbl_Assign_Satisfaction(
          utiltest.panduanNullnew(x._2.getField(0)),utiltest.panduanNullnew(x._2.getField(1)),utiltest.panduantimeNull(x._2.getField(2)),
          utiltest.panduanNullnew(x._2.getField(3)),utiltest.panduantimeNull(x._2.getField(4)),utiltest.panduanNullnew(x._2.getField(5)),
          utiltest.panduanNullnew(x._2.getField(6)),utiltest.panduanNullnew(x._2.getField(7)),utiltest.panduanNullnew(x._2.getField(8)),
          utiltest.panduanNullnew(x._2.getField(9)),utiltest.panduanNullnew(x._2.getField(10)),utiltest.panduantimeNull(x._2.getField(11)),
          utiltest.panduanNullnew(x._2.getField(12)),utiltest.panduanNullnew(x._2.getField(13)),utiltest.panduantimeNull(x._2.getField(14)),
          utiltest.panduanNullnew(x._2.getField(15)),utiltest.panduanNullnew(x._2.getField(16)),utiltest.panduanNullnew(x._2.getField(17)),
          utiltest.panduanNullnew(x._1.getField(3))
        )
      }
      //数据输出到es的满意度表中
      val elasticsearchSinkFunction_satisfaction = new ElasticsearchSinkFunction[Tbl_Assign_Satisfaction] {
        def  createIndexRequest(element: Tbl_Assign_Satisfaction):IndexRequest = {
          val json = JsonBeanUtil.getTblAssignSatisfaction(element)
          //          println("测试转换后的json数据："+json)
          Requests.indexRequest.index(Constant.TBL_ASSIGN_SATISFACTION_INDEX)
            .`type`(Constant.ES_TYPE)
            .id(element.id)
            .source(json)
        }
        override def process(element: Tbl_Assign_Satisfaction, ctx: RuntimeContext, indexer: RequestIndexer): Unit = {
          indexer.add(createIndexRequest(element))
        }
      }
      val outputFormat = new ElasticsearchOutputFormat.Builder[Tbl_Assign_Satisfaction](
        httplist,config,elasticsearchSinkFunction_satisfaction)
        .build()
      satisfactiontest.output(outputFormat)
    }

    //模拟从云上抓取需要的新增阅读数据
    if (list_xzyd.nonEmpty){
       val xzyd:DataSet[Row] = env.createInput(
         JDBCInputFormat.buildJDBCInputFormat()
           .setDrivername(Constant.JDBC_DRIVENAME)
           .setDBUrl(Constant.YUN_URL)
           .setUsername(Constant.YUN_USER)
           .setPassword(Constant.YUN_PASSWORD)
           .setQuery(sql_xzyd)
           .setRowTypeInfo(new RowTypeInfo(
             BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO,
             SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.LONG_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,
             BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.INT_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,
             BasicTypeInfo.INT_TYPE_INFO,SqlTimeTypeInfo.TIMESTAMP,BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO,
             BasicTypeInfo.STRING_TYPE_INFO,BasicTypeInfo.STRING_TYPE_INFO
           ))
           .setFetchSize(1)
           .finish()
       )
       //关联抓取时间ts字段
      val result_xzyd = readdata.join(xzyd).where(0).equalTo(_.getField(0).toString)
      //Row类型转换成实体类
      val xzydtest:DataSet[Tbl_Assign_Xzyd] = result_xzyd.map{
        x => Tbl_Assign_Xzyd(
          utiltest.panduanNullnew(x._2.getField(0)),utiltest.panduanNullnew(x._2.getField(1)),utiltest.panduantimeNull(x._2.getField(2)),
          utiltest.panduanNullnew(x._2.getField(3)),utiltest.panduantimeNull(x._2.getField(4)),utiltest.panduanNullnew(x._2.getField(5)),
          utiltest.panduanNullnew(x._2.getField(6)),utiltest.panduantimeNull(x._2.getField(7)),utiltest.panduanNullnew(x._2.getField(8)),
          utiltest.panduanNullnew(x._2.getField(9)),utiltest.panduanNullnew(x._2.getField(10)),utiltest.panduanNullnew(x._2.getField(11)),
          utiltest.panduanNullnew(x._2.getField(12)),utiltest.panduantimeNull(x._2.getField(13)),utiltest.panduanNullnew(x._2.getField(14)),
          utiltest.panduanNullnew(x._2.getField(15)),utiltest.panduanNullnew(x._2.getField(16)),utiltest.panduanNullnew(x._2.getField(17)),
          utiltest.panduanNullnew(x._1.getField(3))
        )
      }
      //数据输出到es新增阅读表中
      val elasticsearchSinkFunction_xzyd = new ElasticsearchSinkFunction[Tbl_Assign_Xzyd] {
        def  createIndexRequest(element: Tbl_Assign_Xzyd):IndexRequest = {
          val json = JsonBeanUtil.getTblAssignXzydJson(element)
          //          println("测试转换后的json数据："+json)
          Requests.indexRequest.index(Constant.TBL_ASSIGN_XZYD_INDEX)
            .`type`(Constant.ES_TYPE)
            .id(element.xzid)
            .source(json)
        }
        override def process(element: Tbl_Assign_Xzyd, ctx: RuntimeContext, indexer: RequestIndexer): Unit = {
          indexer.add(createIndexRequest(element))
        }
      }
      val outputFormat = new ElasticsearchOutputFormat.Builder[Tbl_Assign_Xzyd](
        httplist,config,elasticsearchSinkFunction_xzyd)
        .build()
      xzydtest.output(outputFormat)
    }

    //将数据写入kafka进行后续大宽表逻辑开发--全部待补充数据
    val datatokafka:DataSet[(String,String,String,String)] = readdata.map(
      x => (x.getField(0).toString,x.getField(1).toString,x.getField(2).toString,x.getField(3).toString)
    )
    datatokafka.output(KafkaOutputFormat.builderKafkaOutputFormat()
      .setBootstrapServers(Constant.KAFKA_LIST)
      .setTopic(Constant.TOPIC)
      .setAcks("all")
      .setBatchSize("16384")
      .setBufferMemory("33554432")
      .setLingerMs("100")
      .setRetries("2")
      .finish()
    ).setParallelism(1)


    //执行更新tidb数据库数据状态操作
    readdata.output(JDBCOutputFormat.buildJDBCOutputFormat()
      .setDrivername(Constant.JDBC_DRIVENAME)
      .setDBUrl(Constant.TIDB_URL)
      .setUsername(Constant.TIDB_USER)
      .setPassword(Constant.TIDB_PASSWORD)
      .setQuery("update service_dirtydata  set  state = 2  where id = ?  and pgid= ? and  tablename = ? and ts = ? and state = ? and data_describe = ? ")
      .finish()
    )



    env.execute("flink批处理补数模块")


   }

}
