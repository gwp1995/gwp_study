package com.gree.model

case class Tbl_Assign_Appointment(
                                   id: String,
                                   created_by: String,
                                   created_date: String,
                                   last_modified_by: String,
                                   last_modified_date: String,
                                   jssj: String, //用户预约时间：结束时间
                                   kssj: String, //用户预约时间:开始时间
                                   czren: String, //操作人
                                   pgid: String, //派工pgguid
                                   czsj: String, //操作时间
                                   leix: String, //类型
                                   reason: String, //延误类型
                                   beiz: String, //备注
                                   ts:String //数据时间戳
                                 )
