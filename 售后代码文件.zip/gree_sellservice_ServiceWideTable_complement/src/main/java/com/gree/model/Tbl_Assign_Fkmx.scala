package com.gree.model

import java.sql.Timestamp


case class Tbl_Assign_Fkmx(
                            fkid:String,
                            created_by:String,
                            created_date:String,
                            last_modified_by:String,
                            last_modified_date:String,
                            pgid:String,
                            fklb:String,
                            fkjg:String,
                            fknr:String,
                            fkren:String,
                            fkrenmc:String,
                            fksj:String,
                            fkwdno:String,
                            fkwdmc:String,
                            scid:String,
                            scwj:String,
                            qqlyxh:String,
                            fkmxguid:String,
                            wjid:String,
                            ts:String
                      )


