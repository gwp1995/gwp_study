package com.gree.model

import java.sql.Timestamp

class Test {
  var f0:Long = _
  var f1:String =_
  var f2:Timestamp =_
  var f3:String =_
  var f4:Timestamp =_
  var f5:Long =_
  var f6:String =_
  var f7:String =_
  var f8:String =_
  var f9:String =_
  var f10:String =_
  var f11:Timestamp =_
  var f12:String =_
  var f13:String =_
  var f14:String =_
  var f15:String =_
  var f16:String =_
  var f17:String =_
  var f18:String =_


  override def toString = s"Test($f0, $f1, $f2, $f3, $f4, $f5, $f6, $f7, $f8, $f9, $f10, $f11, $f12, $f13, $f14, $f15, $f16, $f17, $f18)"
}
