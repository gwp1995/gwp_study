package com.gree.model

case class ComplementData(
                         id:String ,//主键
                         pgid:String ,//工单号
                         table:String,//数据来源表
                         ts:String ,//数据时间戳
                         state:Int //数据状态
                         )
