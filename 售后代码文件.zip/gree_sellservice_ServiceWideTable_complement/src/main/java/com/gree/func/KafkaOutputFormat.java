package com.gree.func;



import com.google.gson.Gson;
import org.apache.flink.api.common.io.OutputFormat;
import org.apache.flink.configuration.Configuration;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import scala.Tuple4;

import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

public class KafkaOutputFormat implements OutputFormat<Tuple4<String,String,String,String> > {
    private String servers;
    private String topic;
    private String acks;
    private String retries;
    private String batchSize;
    private String bufferMemory;
    private String lingerMS;

    public Producer<String,String> producer;

    public KafkaOutputFormat() {
    }


    public void configure(Configuration parameters) {

    }

    public void open(int taskNumber, int numTasks) throws IOException {
        Properties props = new Properties();
        props.put("bootstrap.servers",this.servers);
        props.put("topic",this.topic);
        props.put("acks",this.acks);
        props.put("retries",this.retries);
        props.put("batchSize",this.batchSize);
        props.put("ling.ms",this.lingerMS);
        props.put("buffer.memory",this.bufferMemory);

        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
     //   props.put("partitioner.class", "com.yngwiewang.KafkaCustomPartitioner");

        producer = new KafkaProducer<String, String>(props);

    }

    public void writeRecord(Tuple4<String, String, String,String> record) throws IOException {

        // 将tuple转换成map
        HashMap map = new HashMap();
        map.put("id",record._1());
        map.put("pgid",record._2());
        map.put("tablename",record._3());
        map.put("ts",record._4());
        //将map通过gson转成json字符串
        Gson gosn = new Gson();
        String jsonstr = gosn.toJson(map);

        producer.send(new ProducerRecord<String, String>(
           this.topic,jsonstr
        ));
    }

    public void close() throws IOException {
         producer.close();
    }

    public static  KafkaOutputFormatBuilder builderKafkaOutputFormat(){
        return new KafkaOutputFormatBuilder();
    }


    public  static  class  KafkaOutputFormatBuilder {
        private final KafkaOutputFormat format;

        protected KafkaOutputFormatBuilder(){
            this.format = new KafkaOutputFormat();
        }

        public KafkaOutputFormatBuilder setBootstrapServers(String val) {
            format.servers = val;
            return this;
        }
        public KafkaOutputFormatBuilder setTopic(String val) {
            format.topic = val;
            return this;
        }

        public KafkaOutputFormatBuilder setAcks(String val) {
            format.acks = val != null ? val : "all";
            return this;
        }

        public KafkaOutputFormatBuilder setRetries(String val) {
            format.retries = val != null ? val : "3";
            return this;
        }

        public KafkaOutputFormatBuilder setBatchSize(String val) {
            format.batchSize = val != null ? val : "16384";
            return this;
        }

        public KafkaOutputFormatBuilder setLingerMs(String val) {
            format.lingerMS = val != null ? val : "1000";
            return this;
        }

        public KafkaOutputFormatBuilder setBufferMemory(String val) {
            format.bufferMemory = val != null ? val : "33554432";
            return this;
        }

        public KafkaOutputFormat finish() {
            if (format.servers == null) {
                throw new IllegalArgumentException("required parameter not found: KafkaBrokerList");
            }
            if (format.topic == null) {
                throw new IllegalArgumentException("required parameter not found: KafkaTopic");
            }
            return format;
        }


    }
}
