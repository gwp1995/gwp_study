package com.gree.constant;

public class Constant {
    //ES配置
    public static final int ES_HTTP_PORT = 9200;
    public static final String ES_SCHEME = "http";
    public static final String ES_HOST100 = "10.2.13.100";
    public static final String ES_HOST101 = "10.2.13.101";
    public static final String ES_HOST102 = "10.2.13.102";
    public static final String ES_TYPE = "_doc";

    //kafka
    public static final String KAFKA_LIST = "10.2.11.215:9092,10.2.11.214:9092,10.2.11.213:9092";
    public static final String TOPIC = "gwp_test";
    //JDBC配置信息
    public static final String JDBC_DRIVENAME = "com.mysql.jdbc.Driver";

    public static final String TIDB_URL = "jdbc:mysql://10.2.13.78:4000/dwd_sellinfor_n01";
    public static final String TIDB_USER = "sellinfor_op";
    public static final String TIDB_PASSWORD = "sell@0402";

    public static final String YUN_URL = "jdbc:mysql://10.2.13.78:4000/ODS_PGXT_SERVICE_N01";
    public static final String YUN_USER = "pgxtpgxt";
    public static final String YUN_PASSWORD = "PGpg>_<!2020#";


    //维修索引以及各个表的主键名称
    public static final String TBL_ASSIGN_INDEX = "default_server_greeshservice_tbl_assign_t1";
    public static final String TBL_ASSIGN_QUERY_ID = "pgid";
    public static final String TBL_ASSIGN_SATISFACTION_INDEX = "default_server_greeshservice_tbl_assign_satisfaction_t1";
    public static final String TBL_ASSIGN_SATISFACTION_QUERY_ID ="id";
    public static final String TBL_ASSIGN_MX_INDEX = "default_server_greeshservice_tbl_assign_mx_t1";
    public static final String TBL_ASSIGN_MX_QUERY_ID ="pgmxid";
    public static final String TBL_ASSIGN_FKMX_INDEX = "default_server_greeshservice_tbl_assign_fkmx_t1";
    public static final String TBL_ASSIGN_FKMX_QUERY_ID = "fkid";
    public static final String TBL_ASSIGN_APPOINTMENT_INDEX = "default_server_greeshservice_tbl_assign_appointment_t1";
    public static final String TBL_ASSIGN_APPOINTMENT_QUERY_ID = "id";
    public static final String TBL_ASSIGN_XZYD_INDEX ="default_server_greeshservice_tbl_assign_xzyd_t1";
    public static final String TBL_ASSIGN_XZYD_QUERY_ID = "xzid";
    public static final String TBL_ASSIGN_FEEDBACK_INDEX = "default_server_greeshservice_tbl_assign_feedback_t1";
    public static final String TBL_ASSIGN_FEEDBACK_QUERY_ID = "id";
    public static final String TBL_ASSIGN_DAIJIAN_INDEX = "default_server_greeshservice_tbl_assign_daijian_t1";
    public static final String TBL_ASSIGN_DAIJIAN_QUERY_ID = "id";
}
