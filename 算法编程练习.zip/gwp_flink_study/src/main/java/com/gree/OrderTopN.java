package com.gree;


import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple1;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.*;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.streaming.api.functions.timestamps.AscendingTimestampExtractor;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import javax.jws.soap.SOAPBinding;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;


/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/10/31
 * Description:使用flink state计算模拟商品点击topn的开发案例
 */

public class OrderTopN {
    /** 商品点击量*/
    public static class ItemViewCount{
        public long itemId;   //商品ID
        public long windowEnd;  //窗口结束时间戳
        public long viewCount;  //点击量
        public static ItemViewCount of(long itemId,long windowEed,long viewCount){
            ItemViewCount result = new ItemViewCount();
            result.itemId = itemId;
            result.windowEnd = windowEed;
            result.viewCount = viewCount;
            return result;
        }
        public String toString(){
            return "(" +itemId + "," +windowEnd+","+ viewCount +")" ;
        }
    }
    /** 用户行为数据*/
    public static class UserBehavior {
        public long userId;
        public long itemId;
        public int categoryId;
        public String behavior;
        public long timestamnp;

        public void setUserId(long userId) {
            this.userId = userId;
        }

        public void setItemId(long itemId) {
            this.itemId = itemId;
        }

        public void setCategoryId(int categoryId) {
            this.categoryId = categoryId;
        }

        public void setBehavior(String behavior) {
            this.behavior = behavior;
        }

        public void setTimestamnp(long timestamnp) {
            this.timestamnp = timestamnp;
        }


        public UserBehavior() {
        }

        public UserBehavior(long userId, long itemId, int categoryId, String behavior, long timestamnp) {
            this.userId = userId;
            this.itemId = itemId;
            this.categoryId = categoryId;
            this.behavior = behavior;
            this.timestamnp = timestamnp;
        }

        public String toString() {
            return "(" + userId + "," + itemId + "," + categoryId + "," + behavior + "," + timestamnp + ")";
        }
    }
    public static void main(String [] args) throws  Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
        env.setParallelism(1);

        DataStreamSource<String> itemstring = env.socketTextStream("10.2.14.161",9999 );
        SingleOutputStreamOperator<UserBehavior> user =  itemstring.flatMap(new FlatMapFunction<String, UserBehavior>() {
            public void flatMap(String value, Collector<UserBehavior> out) throws Exception {
                String[] list = value.split(",");
                UserBehavior userBehavior = new UserBehavior();
                userBehavior.setUserId(Long.valueOf(list[0]));
                userBehavior.setItemId(Long.valueOf(list[1]));
                userBehavior.setCategoryId(Integer.valueOf(list[2]));
                userBehavior.setBehavior(list[3]);
                userBehavior.setTimestamnp(Long.valueOf(list[4]));
                out.collect(userBehavior);
            }
        });
        DataStream<UserBehavior> userBehavior = user;

//        DataStream<ItemViewCount> itemViewCountDataStream =
         DataStream<UserBehavior> tt  =  userBehavior.assignTimestampsAndWatermarks(new AscendingTimestampExtractor<UserBehavior>() {
            @Override
            public long extractAscendingTimestamp(UserBehavior element) {
                //原始数据单位秒，  变成毫秒
//                System.out.println("打印时间戳："+element.timestamnp * 1000);
                return element.timestamnp * 1000;
            }
        })     //过滤出只有点击的数据
                .filter(new FilterFunction<UserBehavior>() {
                    public boolean filter(UserBehavior value) throws Exception {
                        return value.behavior.equals("pv");
                    }
                });

        KeyedStream<UserBehavior,Tuple> t2 = tt.keyBy("itemId");

        WindowedStream<UserBehavior,Tuple,TimeWindow> windowedStream =  t2.timeWindow(Time.hours(1),Time.seconds(3));
//        windowedStream.max("timestamnp").print("打印滑动窗口中最大时间戳数据 !");

        DataStream<ItemViewCount>  result =  windowedStream.aggregate(new CountAgg(),new WindowResultFunction());
        result.print("打印窗口计算的结果！！！！");


//                .keyBy("itemId")
//                .timeWindow(Time.minutes(1),Time.seconds(3))
//                .aggregate(new CountAgg(),new WindowResultFunction())
//                .keyBy("windowEnd")
//                .process(new TopNHotItems(3))
//                .print("打印测试结果====");

//        itemViewCountDataStream.print("查看窗口计数效果");
        env.execute("hot item job");
    }
    /**count 统计的聚合函数实现 ，没出现一条记录加一 */
    public static class CountAgg implements AggregateFunction<UserBehavior,Long,Long>{

        public Long createAccumulator() {
            return 0L;
        }

        public Long add(UserBehavior value, Long accumulator) {
            return accumulator+1;
        }

        public Long getResult(Long accumulator) {
//            System.out.println("打印累加器："+accumulator);
            return accumulator;
        }

        public Long merge(Long a, Long b) {
            return a+b;
        }
    }

    /**用于输出窗口的结果 */
    public static class WindowResultFunction implements WindowFunction<Long,ItemViewCount, Tuple, TimeWindow>{

        public void apply(Tuple key, TimeWindow window, Iterable<Long> input, Collector<ItemViewCount> out) throws Exception {
            System.out.println("进入窗口计算！！！");
           Long itemId = ((Tuple1<Long>) key).f0;
           Long count = input.iterator().next();
           out.collect(ItemViewCount.of(itemId,window.getEnd(),count));
        }
    }
    /** 求某个窗口中前N 名的热门点击商品 key 为窗口时间戳 ，输出为TopN的结果字符串*/
    public static class TopNHotItems extends KeyedProcessFunction<Tuple,ItemViewCount,String>{
        private final  int topSize;
        public TopNHotItems(int topSize){
            this.topSize = topSize;
        }
        //用于存储商品与点击数的状态，待收齐同一个窗口的数据后，在触发topN计算
        private ListState<ItemViewCount> itemState;

        @Override
        public void open(Configuration parameters) throws Exception {
            super.open(parameters);
            ListStateDescriptor<ItemViewCount> itemStateDesc = new ListStateDescriptor<>("itemState-state", ItemViewCount.class);
            itemState = getRuntimeContext().getListState(itemStateDesc);
        }

        public void processElement(ItemViewCount value, Context ctx, Collector<String> out) throws Exception {
            //每条数据都保存到状态中
            itemState.add(value);
            //注册windend +1 的eventtime time，当触发时，说明收集齐了属于windowend窗口的所有商品数据
            ctx.timerService().registerEventTimeTimer(value.windowEnd + 1);
        }

        @Override
        public void onTimer(long timestamp, OnTimerContext ctx, Collector<String> out) throws Exception {
            ArrayList<ItemViewCount> allitems = new ArrayList<>();
            for (ItemViewCount item: itemState.get()){
                allitems.add(item);
            }
            //提前清除状态中的数据，释放空间
            itemState.clear();
            //按照点击量从大到小排序
           allitems.sort(new Comparator<ItemViewCount>() {
               @Override
               public int compare(ItemViewCount o1, ItemViewCount o2) {
                   return (int)(o2.viewCount-o1.viewCount);
               }
           });
           //将排名信息格式化成 String ，便于打印
            StringBuilder result = new StringBuilder();
            result.append("============================\n");
            result.append("时间：").append(new Timestamp(timestamp-1)).append("\n");
            for (int i=0;i<allitems.size() && i< topSize;i++){
                ItemViewCount currentitem = allitems.get(i);
                result.append("No").append(i).append(":")
                        .append(" 商品ID=").append(currentitem.itemId)
                        .append(" 浏览量=").append(currentitem.viewCount)
                        .append("\n");
            }
            result.append("===========================\n");
            //控制输出频率，模拟实时滚动结果
            Thread.sleep(1000);
            out.collect(result.toString());
        }
    }
}
