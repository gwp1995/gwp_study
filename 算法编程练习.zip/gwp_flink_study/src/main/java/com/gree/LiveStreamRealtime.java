package com.gree;

import com.sun.xml.internal.ws.streaming.SourceReaderFactory;
import org.apache.flink.api.common.functions.RichFlatMapFunction;

import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import java.util.List;


/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/18
 * Description:
 */

public class LiveStreamRealtime {
    static class SourceModel{
        private Long liveStreamId;
        private Long time;
        private Long authorId;
        private long binlongTimestamp;
        private BizType bizType;

        public SourceModel(Long liveStreamId, Long time, Long authorId, long binlongTimestamp, BizType bizType) {
            this.liveStreamId = liveStreamId;
            this.time = time;
            this.authorId = authorId;
            this.binlongTimestamp = binlongTimestamp;
            this.bizType = bizType;
        }
    }
    enum BizType{
        I,
        D,
        ;
    }
    static class SinkModel{
        private long timestamp;
        private String metricName;
        private long metricValue;

        public SinkModel(long timestamp, String metricName, long metricValue) {
            this.timestamp = timestamp;
            this.metricName = metricName;
            this.metricValue = metricValue;
        }

        @Override
        public String toString() {
            return "SinkModel{" +
                    "timestamp=" + timestamp +
                    ", metricName='" + metricName + '\'' +
                    ", metricValue=" + metricValue +
                    '}';
        }
    }
    public static void main(String [] args){
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStream<String> source =  env.socketTextStream("10.2.14.161",9999);
        DataStream<SourceModel> resource = source.flatMap(new RichFlatMapFunction<String, SourceModel>() {
            @Override
            public void flatMap(String value, Collector<SourceModel> out) throws Exception {
                String[] str = value.split(",");
                out.collect(new SourceModel(Long.valueOf(str[0]),Long.valueOf(str[1]),Long.valueOf(str[2]),Long.valueOf(str[3]),BizType.valueOf(str[4])));
            }
        });
        DataStream<SinkModel> result = resource
                .keyBy(new KeySelector<SourceModel,Long>(){
                    @Override
                    public Long getKey(SourceModel value) throws Exception {
                        return value.liveStreamId % 1000;
                    }
                }).timeWindow(Time.seconds(60))
                .process(new ProcessWindowFunction<SourceModel, SinkModel, Long, TimeWindow>() {
                    ValueState<Long> playingLiveStreamNumberValueState;
                    @Override
                    public void open(Configuration parameters) throws Exception {
                        super.open(parameters);
                        ValueStateDescriptor<Long> playingLivedes = new ValueStateDescriptor<>("playing-descripe",Long.class);
                        this.playingLiveStreamNumberValueState = getRuntimeContext().getState(playingLivedes);
                    }

                    @Override
                    public void process(Long aLong, Context context, Iterable<SourceModel> elements, Collector<SinkModel> out) throws Exception {
                        Long playingLivenumber = this.playingLiveStreamNumberValueState.value();
                        if (playingLivenumber == 0){
                            playingLivenumber = 0L;
                        }
                        List<SourceModel> sourceModelList = (List<SourceModel>)elements;
                        for (SourceModel sourceModel:sourceModelList){
                            if (sourceModel.bizType == BizType.I){
                                playingLivenumber++;
                            }else {
                                playingLivenumber--;
                            }
                        }
                        this.playingLiveStreamNumberValueState.update(playingLivenumber);
                        out.collect(new SinkModel(System.currentTimeMillis() / 1000,"直播间人数统计",playingLivenumber));
                    }
                });
        result.print("测试打印窗口状态计数！！！！");

    }
}
