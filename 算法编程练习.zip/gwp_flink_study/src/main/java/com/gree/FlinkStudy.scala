package com.gree


import org.apache.flink.api.common.functions.RichFlatMapFunction
import org.apache.flink.api.common.state.{ValueState, ValueStateDescriptor}
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.slf4j.{Logger, LoggerFactory}
import org.apache.flink.api.scala._
import org.apache.flink.configuration.Configuration
import org.apache.flink.util.Collector
/**
  * @Author: Ge WanPeng
  * @Date: Create in  2020/7/24
  *        Description:
  */

object FlinkStudy {
  def main(args: Array[String]): Unit = {

    val logger:Logger = LoggerFactory.getLogger(FlinkStudy.getClass)
    val fsEnv = StreamExecutionEnvironment.getExecutionEnvironment
    //设置并行度
    fsEnv.setParallelism(1)

   fsEnv.fromCollection(List(
     (1,3),
     (1,5),
     (1,6),
     (1,9),
     (1,12)
   )).keyBy(_._1)
       .flatMap(new RichFlatMapFunction[(Int,Int),(Int,Int)] {
         //定义state
         var state:ValueState[(Int,Int)] = _
         //获取state
         override def open(parameters: Configuration): Unit = {
          state = getRuntimeContext.getState(
             new ValueStateDescriptor[(Int,Int)]("avg",createTypeInformation[(Int,Int)])
           )
         }
         override def flatMap(value: (Int, Int), out: Collector[(Int, Int)]): Unit = {

           val tempstate = state.value()
           println("打印测试state.value的值："+state.value())
           println("打印当前进入的value值："+value)
           val currentState = if (tempstate != null){
             tempstate
           }else{
             (0,0)
           }
           //更新
           val newState = (currentState._1+1,currentState._2 + value._2)
           state.update(newState)
           if (newState._1 >= 2) {
             out.collect((value._1,newState._2 / newState._1))
//             state.clear()
           }
         }
       }).print("测试打印！！！！")

    fsEnv.execute("flink测试学习")
  }

}
