package com.gwp.幕客网真题编程练习202009;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/9/25
 * Description: 有一个N*N整数矩阵，将矩阵顺时针旋转90度
 */

public class Test10 {
    public static int[][] rotateMatrix(int[][] mat,int n){
        int[][] result = new int[n][n];
        for (int j=0;j<n;j++){
            for (int i=n-1,k=0;i>=0 && k<n;i--,k++ ){
                result[j][k] = mat[i][j];
//                System.out.println("打印数据角标j："+j+" 打印数组角标K："+k+" 打印每次取数结果："+result[j][k]);
            }
        }
        return result;
    }
    public static void main(String [] args){
        int[][] test ={{1,2,3},{4,5,6},{7,8,9}};
        int[][] results = rotateMatrix(test,3);
        System.out.println(Arrays.deepToString(results));
    }
}
