package com.gwp.幕客网真题编程练习202009;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/9/22
 * Description: 假设你有一个数组，其中第i个元素是股票在第i天的价格。你有一次买入和卖出的机会。设计一个算法来计算可以获得的最大利益
 */

public class Test7 {
    public static int maxshouyi(int[] a){
        int max=0;
        for (int i=0;i<a.length;i++){
            for (int j=i+1;j<a.length;j++){
                if (a[j] - a[i] > max){
                    max = a[j] - a[i];
                }
            }
        }
        return max;
    }
    public static int maxprofit(int[] arr){
        int minvalue = arr[0];
        int profit = 0;
        for (int i=1;i<arr.length;i++){
            if (arr[i] < minvalue){
                minvalue = arr[i];
            }
            profit=Math.max(profit,arr[i]-minvalue);
        }
        return profit;
    }
    public static void main(String [] args){
        int[] test = {2,4,1};
        System.out.println(maxprofit(test));
    }
}
