package com.gwp.幕客网真题编程练习202009;

import org.omg.CORBA.Any;

import java.util.*;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/9/18
 * Description: 统计字符串中字符出现的次数
 */

public class Test4 {
    public static Map  countzifu(char[] chars){
        Map<Character,Integer> map = new HashMap<>();
        for (int i=0;i<chars.length;i++){
            if (map.get(chars[i]) == null){
                map.put(chars[i],1);
            } else {
              Integer y = map.get(chars[i]);
              y++;
              map.put(chars[i],y);
            }
        }
        return  map;

    }
    public static void main(String [] args){
        Scanner scanner = new Scanner(System.in);
        char[] test = scanner.next().toCharArray();
        Map<Character,Integer> tt = countzifu(test);
        for (Map.Entry i: tt.entrySet()){
            System.out.println(i.getKey()+ " == "+ i.getValue());
        }
//        System.out.println(countzifu(test));
    }
}
