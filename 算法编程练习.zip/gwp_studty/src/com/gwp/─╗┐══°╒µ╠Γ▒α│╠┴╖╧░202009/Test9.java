package com.gwp.幕客网真题编程练习202009;

import java.util.*;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/9/23
 * Description: 一个没有重复元素的整数集合S，求S的所有子集。给出的子集中的元素必须按升序
 */

public class Test9 {
    public ArrayList<ArrayList<Integer>> subsets(int[] s){
        if (s.length <0 && s == null) return null;
        ArrayList<ArrayList<Integer>> result = new ArrayList<>();
        ArrayList<Integer> list = new ArrayList<>();
        Arrays.sort(s);
        dfs(s,result,list,0);
        Collections.sort(result, new Comparator<ArrayList<Integer>>() {
            @Override
            public int compare(ArrayList<Integer> o1, ArrayList<Integer> o2) {
                if(o1.size() > o2.size()){
                    return 1;
                }
                else if(o1.size() < o2.size()){
                    return -1;
                }
                else {
                    return 0;
                }
            }
        });
        return result;
    }
    public ArrayList<ArrayList<Integer>> violence(int[] arr){
        if (arr.length < 1 && arr == null) return null;
        ArrayList<ArrayList<Integer>> result = new ArrayList<>();
        ArrayList<Integer> list = new ArrayList<>();
        Arrays.sort(arr);
        result.add(new ArrayList<>(list));
        for (int i=0;i<arr.length;i++){
            list.add(arr[i]);
            if (!result.contains(list)){
                result.add(new ArrayList<>(list));
            }
            for (int j=i+1;j<arr.length;j++){
                list.add(arr[j]);
                if (!result.contains(list)){
                    result.add(new ArrayList<>(list));
                }
            }
            list.clear();
        }
        return result;
    }
    public void dfs(int[] num, ArrayList<ArrayList<Integer>>  result,ArrayList<Integer> list,int start){
           result.add(new ArrayList<>(list));
           for (int i=start;i<num.length;i++) {
               list.add(num[i]);
               dfs(num, result, list, i + 1);
               list.remove(list.size() - 1);
           }
    }
    public static void main(String [] args){
        Test9 test9 = new Test9();
        int[]  test = {1,2,3};
        ArrayList<ArrayList<Integer>> arrayLists = test9.subsets(test);
        System.out.println(arrayLists);
//        for (ArrayList<Integer> arrayList: arrayLists) {
//            System.out.println(arrayList);
//        }

    }
}
