package com.gwp.幕客网真题编程练习202009;

import java.util.Arrays;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/9/21
 * Description:合并2个有序的整数数组，a，b。将a数组合并到b数组。假设b数组有足够的空间。
 */

public class Test6 {
    public int[]  merge(int[] a,int m,int[] b,int n){
        int[] c = new int[m+n];
        int x = 0;
        int i =0;
        int j=0;
        while (i < m && j < n){
            if (a[i] < b[j]){
                c[x] = a[i];
                i++;
                x++;
            }else {
                c[x] = b[j];
                j++;
                x++;
            }
        }
        while (i < m) {
            c[x] = a[i];
            i++;
            x++;
        }
        while (j < n){
            c[x] = b[j];
            j++;
            x++;
        }
        return c;
    }
    public static void main(String [] args){
        Test6 test6 = new Test6();
        int[] a={1,3,5,7,9};
        int[] b={2,4,6,8,10};
        int[] cc=test6.merge(a,5,b,5);
        System.out.println(Arrays.toString(cc));
    }
}
