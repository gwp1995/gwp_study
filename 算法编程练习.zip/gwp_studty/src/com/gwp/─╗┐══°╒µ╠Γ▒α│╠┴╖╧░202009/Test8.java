package com.gwp.幕客网真题编程练习202009;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/9/22
 * Description: 给出一组候选数据c和一个目标T，找出候选数据中加起来的和为T的所有集合。
 * C中每个数字在一个组合中中能使用一次
 */

public class Test8 {
    public  ArrayList<ArrayList<Integer>> combinationsum(int[] num,int target){
        ArrayList<ArrayList<Integer>> result = new ArrayList<>();
        ArrayList<Integer> arrayList = new ArrayList<>();
        if (num.length <= 0 && num == null) return null;
        Arrays.sort(num);
        System.out.println("开始进入深度所有方法：");
        dfs(num,arrayList,result,0,target);
        System.out.println("执行深度搜索完成：");
        return result;
    }
    public void dfs(int[] num,ArrayList<Integer> list,ArrayList<ArrayList<Integer>> res,int start,int target){
        System.out.println("进入dfs方法内");
        if (target == 0 && !res.contains(list)){
            System.out.println("添加满足条件的list集合");
            res.add(new ArrayList<>(list));
        }
        if (target < 0) return;
        for (int i=start;i<num.length;i++){
            if (i > start && num[i] == num[i-1]){
                continue;
            }
            if (num[i] <= target){
                list.add(num[i]);
                System.out.println("打印剩余sum的值："+(target-num[i]));
                dfs(num,list,res,i+1,target-num[i]);
                System.out.println("回退前集合数值： "+list);
                list.remove(list.size()-1);
                System.out.println("回退后集合数值： "+list);
            }
        }
    }
    public static void main(String [] args){
        int[] test = {10,1,2,7,6,1,5};
        int[] tt = {1};
        int target=1;
        Test8 test8 = new Test8();
        ArrayList<ArrayList<Integer>> arrayLists =test8.combinationsum(tt,target);
        for (ArrayList<Integer> arrayList: arrayLists) {
            System.out.println(arrayList);
        }
    }
}
