package com.gwp.幕客网真题编程练习202009;

import java.util.Date;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/9/15
 * Description: n皇后问题 回溯求解
 */

public class Test3 {
    private static final short N=8; //初始定义棋盘大小为8
    private static  int count=0; //结果计数器

    public static void  putqueenatrow(int[][] chess,int row){
        //递归终止条件，如果row == n ，则说明已经成功
        if (row == N){
            count++;
            System.out.println("第" +count+" 种解:");
            for (int i=0;i < N;i++){
                for (int j=0;j<N;j++){
                    System.out.println(chess[i][j]+"");
                }
                System.out.println();
            }
            return;
        }

        int[][] chesstemp = chess.clone();

        /**
         * 向这一行的每个位置尝试排放皇后
         * 然后检查状态是否满足
         */
        for (int i=0;i<N;i++){
            for (int j=0;j<N;j++){
                chesstemp[row][j] = 0;
            }
            chesstemp[row][i] = 1;
            if (isSafety(chesstemp,row,i)){
                putqueenatrow(chesstemp,row+1);
            }
        }

    }

    public static boolean isSafety(int[][] chess,int row,int i){
        //判断中上、左上、右上是否安全
        int step=1;
        while (row - step >=0){
            if (chess[row-step][i] == 1)
                return false;
            if (i - step >= 0 && chess[row-step][i-step] == 1)
                return false;
            if (i + step <N && chess[row+step][i+step] == 1)
                return false;
            step++;
        }
        return true;
    }


    public static void main(String [] args){
        Date begin = new Date();
        //初始化棋盘
        int[][] chess = new int[N][N];
        for (int i=0;i < N;i++){
            for (int j=0;j<N;j++){
                chess[i][j] = 0;
            }
        }

        putqueenatrow(chess,0);
        Date end = new Date();
        System.out.println("用时："+String.valueOf(end.getTime()-begin.getTime()) + "毫秒，计算结果："+ count);
    }
}
