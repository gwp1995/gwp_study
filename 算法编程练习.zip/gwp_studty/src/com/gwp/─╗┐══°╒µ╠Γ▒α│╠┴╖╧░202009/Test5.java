package com.gwp.幕客网真题编程练习202009;

import java.util.Arrays;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/9/21
 * Description: 给定一个数组，编写一个函数所有0移动到数组末尾，同时保证非0元素有序
 * 不允许申请新数组，时间复杂度O（n）
 */

public class Test5 {

    public static void movesort(int[] arr){
        int len  = arr.length;
        int count = 0;
        for (int i=0;i<len;i++){
            if (arr[i] == 0){
                count++;
            }else {
                arr[i-count] = arr[i];
                arr[i] = 0;
            }
        }
    }
    public static void main(String [] args){
        int[] test={0,1,0,2,0,3,6,0,11};
        movesort(test);
        System.out.println(Arrays.toString(test));
    }
}
