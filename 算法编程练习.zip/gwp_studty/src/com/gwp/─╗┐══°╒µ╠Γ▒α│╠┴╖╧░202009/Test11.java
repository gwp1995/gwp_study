package com.gwp.幕客网真题编程练习202009;

import java.util.Arrays;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/9/27
 * Description: 给定一个无序数组arr，找到数组中未出现的最小正整数
 * 例如arr=[-1,2,3,4] 返回1
 */

public class Test11 {
    public static int minnumber(int[] arr){
        int index = 1;
        int minnum = 1;
        if (arr.length < 1 && arr == null){
            minnum = -1;
        }
        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));
        for (int i=0;i<arr.length;i++){
             if (arr[i] <= 0){
                 continue;
             }
             if (i == arr.length-1 && arr[i] == index){
                 minnum = index + 1;
             }
             if (arr[i] != index){
                 minnum = index;
             }else {
                index++;
             }

        }
        return minnum;
    }
    public static void main(String [] args){
        int[] test={-1,-3,2,1,7};
        System.out.println(minnumber(test));

    }
}
