package com.gwp.幕客网真题编程练习202009;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/9/15
 * Description: 二分查找有序数组大于等于target的第一个位置
 */

public class Test2 {
    public static int bullsort(int[] arr,int target,int left ,int right){
        int mid = (left + right) / 2 ;
        if (left < right){
            if (arr[mid] > target){
                 return bullsort(arr,target,left,mid-1);
            }
            if (target > arr[mid]){
                 return bullsort(arr,target,mid+1,right);
            }else {
                while (target == arr[mid] && mid >= left ){
                    mid--;
                }
                return  mid + 1;
            }
        }else {
            if (arr[mid] > target){
               return mid - 1;
            }else {
                return mid + 1;
            }
        }
    }
    public static void main(String [] args){
        int[] arr={1,2,3,4,5,5,5,5,6,8,9,22,44};
        int tt = bullsort(arr,5,0,arr.length-1);
        System.out.println(tt);
    }
}
