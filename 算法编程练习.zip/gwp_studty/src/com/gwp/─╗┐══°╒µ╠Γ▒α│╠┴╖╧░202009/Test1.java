package com.gwp.幕客网真题编程练习202009;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/9/7
 * Description:
 */

public class Test1 {
    public static void  quick(int[] a,int left,int right){
        if (right > left){
            int povit = left;
            int i=left;
            int j=right;
            while ( i < j){
                while (a[j] >= a[povit] && i < j){
                    j--;
                }
                while (a[i] <= a[povit]  && i < j){
                    i++;
                }
                if (j != i){
                    int temp = a[j];
                    a[j] = a[i];
                    a[i] = temp;
                }
            }
            int temp = a[i];
            a[i] = a[povit];
            a[povit] = temp;
            quick(a,left,i-1);
            quick(a,i+1,right);
        }
    }
    public static  int maxqujian(int[] a){
        int max=0;
        for (int i=0;i< a.length;i++){
            int sum= a[i];
            int value = a[i];
            int left = i-1;
            int right = i+1;
            while (left >=0 && a[left] >= value){
                sum += a[left];
                left--;
            }
            while (right >=0 && a[right] >= value){
                sum += a[right];
                right++;
            }
            max = Math.max(max,sum*value);
        }
        return max;
    }

    public static int maxqujianzhi(int[] a){
        int max=0;
        for (int i=0;i< a.length;i++){
            int sum= a[i];
            int min = a[i];
            for (int j=i;j<a.length;j++){
                if (a[j] < min ){
                    min = a[j];
                }
                if (j == i){
                    max = Math.max(a[i]*a[i],max);
                }
                if (j != i){
                    sum += a[j];
                    max = Math.max(sum*min,max);
                }
            }
        }
        return max;
    }
    public static void main(String [] args){
//        Random random = new java.util.Random(20);
//        for (int i=0;i< 10 ;i++){
//            System.out.println(random.nextInt(10));
//        }

        Scanner scanner = new Scanner(System.in);
        int t = scanner.nextInt();
        int[] arr = new int[t];
        int i=0;
        while (t > 0){
            int yy = scanner.nextInt();
            arr[i] = yy;
            t--;
            i++;
        }
        quick(arr,0,arr.length-1);
        System.out.println(maxqujian(arr));
    }
}
