package com.gwp.多线程练习;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/16
 * Description:
 */
class MyThread extends Thread{
    @Override
    public void run() {
        for (int i=0;i<100;i++){
            System.out.println("=======");
        }
    }
}
class RunableTest implements Runnable{

    @Override
    public void run() {
        System.out.println("-=-=-=-=-");
    }
}
public class TestMyThread {
    public static void main(String [] args){
        MyThread myThread = new MyThread();
        myThread.run();
        for (int j=0;j<100;j++){
            System.out.println("---------");
        }
    }
}
