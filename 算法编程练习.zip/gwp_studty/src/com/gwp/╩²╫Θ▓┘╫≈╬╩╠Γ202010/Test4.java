package com.gwp.数组操作问题202010;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/13
 * Description: 判断一个整数数组是不是某个二叉树的后序遍历结果
 */

public class Test4 {
    public static boolean gobst(int[] arr,int start,int end){
        if (start >= end ) return true;
        int root = arr[end];
        int i= start;
        while (arr[i] < root){
            i++;
        }
        for (int j= i;j<end;j++){
            if (arr[j] < root) return false;
        }
        return  gobst(arr,start,i-1) && gobst(arr,i,end-1);
    }
    public static boolean bst(int[] arr){
        if (arr.length == 0) return false;
        return gobst(arr,0,arr.length-1);
    }
    public static void main(String [] args){
        int[] test = {10,8,9};
        System.out.println(bst(test));
    }
}
