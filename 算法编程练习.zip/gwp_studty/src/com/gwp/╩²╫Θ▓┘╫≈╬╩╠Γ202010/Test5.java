package com.gwp.数组操作问题202010;

import java.util.HashMap;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/26
 * Description:找出数组中出现次数超过数组长度一半的数字，有则输出，没则输出0
 */

public class Test5 {
    public static int Moresolution(int[] arr){
        HashMap<Integer,Integer> maps = new HashMap<>();
        int len = (int)Math.ceil(arr.length / 2);
        for (int i=0;i<arr.length;i++){
            if (maps.containsKey(arr[i])){
                maps.put(arr[i],maps.get(arr[i]) + 1);
            }else{
                maps.put(arr[i],1);
            }
        }
        for (HashMap.Entry<Integer,Integer> map:maps.entrySet()){
            if (map.getValue() >= len+1){
                return map.getKey();
            }
        }
        return 0;
    }
    public static void main(String [] args){
        int[] test = {1,2,3,2,2,2,5,4,2};
        int result =  Moresolution(test);
        System.out.println(result);
    }
}
