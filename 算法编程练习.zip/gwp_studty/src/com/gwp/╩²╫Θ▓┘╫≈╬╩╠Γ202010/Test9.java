package com.gwp.数组操作问题202010;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/12/7
 * Description: 输入一个正整数，把数组里面所有数字拼接起来组成一个数，打印能拼接出的所有数字中最小的一个。
 */

public class Test9 {
    public static String PrintMinnumber(int[] arr){
        String[] str = new String[arr.length];
        StringBuilder ab = new StringBuilder();
        for (int i=0;i<arr.length;i++){
            str[i] = String.valueOf(arr[i]);
        }
        Arrays.sort(str,new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                String c1 = o1+o2;
                String c2 = o2+o1;
                return c1.compareTo(c2);
            }
        });
        for (int j=0;j<str.length;j++){
            ab.append(str[j]);
        }
        return ab.toString();
    }
    public static void main(String [] args){
        int[] test = {2,3,4,9,6};
        System.out.println(PrintMinnumber(test));
    }
}
