package com.gwp.数组操作问题202010;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/30
 * Description: 最大连续子序列和
 */

public class Test7 {
    public static int maxsum(int[] arr){
        if (arr == null || arr.length == 0) return 0;
        int res = arr[0];
        int maxsum=arr[0];
        for (int i=1;i<arr.length;i++){
            maxsum = Math.max(maxsum+arr[i],arr[i]);
            res = Math.max(maxsum,res);
        }
        return res;
    }
    public static void main(String [] args){
        int[] test = {1,-2,3,10,-4,7,2,-5};
        int[] test1 = {-2,-8,-1,-5,-9};
        int result = maxsum(test);
        System.out.println(result);
    }
}
