package com.gwp.数组操作问题202010;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/12/10
 * Description: 把只包含因子2，3和5的数称作丑数。例如6,8都是丑数，但是14不是因为包含了7.习惯上我们把1当做是第一个丑数。按从小到大的顺序的第N个丑数
 */

public class Test10 {
    static final int d[] = {2,3,5};
    public static int finmin(int num2,int num3,int num5){
        int min = Math.min(num2,Math.min(num3,num5));
        return min == num2 ? 0: min == num3 ? 1:2;
    }
    public static int Getuglynumber(int index){
        if (index == 0) return 0;
        int a[] = new int[index];
        a[0] = 1;
        int p[] = new int[] {0,0,0};
        int num[] = new int[] {2,3,5};
        int cur=1;
        while (cur < index){
            int m = finmin(num[0],num[1],num[2]);
            if (a[cur-1] < num[m]){
                a[cur++] = num[m];
                p[m] += 1;
                num[m] = a[p[m]] * d[m];
            }
        }
        return a[index-1];
    }

    public static void main(String [] args){
    }
}
