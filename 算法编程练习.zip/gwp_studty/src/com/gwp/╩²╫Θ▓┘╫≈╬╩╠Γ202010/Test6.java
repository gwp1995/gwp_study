package com.gwp.数组操作问题202010;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/27
 * Description: 给一个整数数组，输出数组汇总最小的k个数
 */

public class Test6 {
    public static ArrayList<Integer> getknumber(int[] arr,int k){
        ArrayList<Integer> list = new ArrayList<>();
        if (arr.length == 0 || arr == null) return new ArrayList<>();
        for (int i = arr.length/2 -1;i>=0;i--){
            adjustmaxheap(arr,i,k);
        }
        for (int j=k;j<arr.length;j++){
            if (arr[j]<arr[0]){
                int temp = arr[j];
                arr[j] = arr[0];
                arr[0] = temp;
                adjustmaxheap(arr,0,k);
            }
        }
        for (int i=0;i<k;i++){
            list.add(arr[i]);
        }
        return list;
    }
    //构建大顶堆
    public static void adjustmaxheap(int[] arr,int i,int length){
        int tt = arr[i];
        for (int k=2*i+1;k<length;k = 2*k +1){
            if (k+1<length && arr[k]<arr[k+1] ){
                k++;
            }
            if (arr[k]>tt){
                arr[i] = arr[k];
                i = k;
            }else {
                break;
            }
        }
        arr[i] = tt;
    }
    //快排 nlogn复杂
    public static void quicksort(int[] arr,int left,int right){
        if (right>left) {
            if (arr.length == 0 || arr == null) return;
            int pvoit = arr[left];
            int i = left;
            int j = right;
            while (i < j) {
                while (arr[j] >= pvoit && j > i)
                    j--;
                while (arr[i] <= pvoit && i < j)
                    i++;
                if (j != i) {
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
            int temp = arr[i];
            arr[i] = arr[left];
            arr[left] = temp;
            quicksort(arr, left, i - 1);
            quicksort(arr, i + 1, right);
        }
    }
    public static ArrayList<Integer> getleastnumber(int[] arr,int k){
        ArrayList<Integer> list = new ArrayList<>();
        for (int i=0;i<k;i++){
            list.add(arr[i]);
        }
        return list;
    }
    public static void main(String [] args){
        int[] test = {4,5,1,6,2,7,3,8};
//        quicksort(test,0,test.length-1);
        ArrayList<Integer> result =  getknumber(test,8);
        System.out.println(result);

    }
}
