package com.gwp.数组操作问题202010;

import java.util.ArrayList;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/11
 * Description: 顺时针打印一个矩阵的数字
 */

public class Test3 {
    public static ArrayList<Integer> printmatrix(int[][] arr){
        ArrayList<Integer> arrayList = new ArrayList<>();
        if (arr.length == 0) return null;
        int startrow = 0;
        int startcol = 0;
        int endrow = arr.length -1;
        int endcol = arr[0].length -1;
        while (startrow <= endrow && startcol <= endcol){
            //只剩一行
            if (startrow == endrow){
                for (int j=startcol;j<=endcol;j++){
                    arrayList.add(arr[startrow][j]);
                }
                return arrayList;
            }
            //只剩一列
            if (startcol == endcol){
                for (int j=startrow;j<=endrow;j++) {
                    arrayList.add(arr[j][startcol]);
                }
                return arrayList;
            }
            //首行
            for (int j=startcol;j<=endcol;j++){
                arrayList.add(arr[startrow][j]);
            }
            startrow +=1;
            //末列
            for (int j=startrow;j<=endrow;j++){
                arrayList.add(arr[j][endcol]);
            }
            endcol -=1;
            //末行
            for (int j=endcol;j>=startcol;j--){
                arrayList.add(arr[endrow][j]);
            }
            endrow -=1;
            //首列
            for (int j=endrow;j>=startrow;j--){
                arrayList.add(arr[j][startcol]);
            }
            startcol +=1;

            System.out.println(startrow+"--"+endrow+"--"+startcol+"--"+endcol);
        }
        return arrayList;
    }
    public static void main(String [] args){
        int[][] test = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
        int[][] test1 = {{1,2},{3,4}};
        int[][] test2 = {{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15}};
        int[][] test3 = {{1}};
        ArrayList<Integer> tt =  printmatrix(test3);
        System.out.println(tt);
    }
}
