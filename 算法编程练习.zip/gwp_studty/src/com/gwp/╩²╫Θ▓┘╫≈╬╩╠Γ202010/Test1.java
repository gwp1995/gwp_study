package com.gwp.数组操作问题202010;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/10/27
 * Description: 将一个数组中为0的值全部移动到数据末尾，并且前面非0值之间相对顺序不变
 * [0,1,3,5,0,7,8,0,9]  [1,3,5,7,8,9,0,0,0]
 */

public class Test1 {
    public static void  movezero(int[] arr){
        int count = 0;
        if (arr.length == 0)
            return;
        for (int i=0;i<arr.length;i++){
            if (arr[i] == 0){
                count++;
            }else {
                arr[i-count] = arr[i];
                arr[i] = 0;
            }
        }
    }
    //将奇数移到偶数前面并保证奇数与奇数，偶数与偶数之间顺序不变
    public static int[] moveoushu(int[] arr){
        int jishucount=0;
        int jishubegin=0;
        int[] result = new int[arr.length];
        for (int i=0;i<arr.length;i++){
            if (arr[i] % 2 !=0){
                jishucount++;
            }
        }
        for (int j=0;j<arr.length;j++){
            if (( arr[j] & 1) ==1 ){
                result[jishubegin] = arr[j];
                jishubegin++;
            }else {
                result[jishucount] = arr[j];
                jishucount++;
            }
        }
        return result ;
    }
    public static void main(String [] args){
        int[] test = {0,1,3,5,0,7,8,0,9};
        int[] tt = {2,1,3,4,6,8,7,9,10};
//        movezero(test);
       int[] result =  moveoushu(tt);
        System.out.println(Arrays.toString(result));
    }
}

