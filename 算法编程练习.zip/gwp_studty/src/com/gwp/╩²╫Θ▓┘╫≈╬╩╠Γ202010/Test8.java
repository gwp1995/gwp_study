package com.gwp.数组操作问题202010;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/12/3
 * Description: 求1-n中1出现的次数
 */
public class Test8 {

    public static int Number1between(int n){
        if (n <=0) return 0;
        int cout =1;
        if (n <10) return cout;
        return cout;
    }
    public static void main(String [] args){
    }
}
