package com.gwp.数组操作问题202010;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2021/1/13
 * Description: 大数组求中位数，利用快速排序的切片思想来解决
 */

public class Test12 {
    public  static int qiepian(int[] arr,int left,int right){
        if (arr.length == 0 || arr == null) return 0;
        int i=left;
        int j=right;
        int povit = arr[left];
        while (i<j){
            while (arr[j]>= povit && j>i){
                j--;
            }
            while (arr[i] <= povit && i<j){
                i++;
            }
            if (i != j){
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp = arr[i];
        arr[i] = povit;
        arr[left] = temp;
        return i;
    }
    public static int  zhongshu(int[] arr,int k){
        int left = 0,right = arr.length-1;
        while (right > left){
            int j=qiepian(arr,left,right);
            if (k == j) return arr[k];
            else if (k > j) left = j+1;
            else if (k < j) right = j-1;
        }
        return arr[k];
    }
    public static void main(String [] args){
        int[] test = {4,3,7,6,2,5,1};
        System.out.println(zhongshu(test,2));
    }
}
