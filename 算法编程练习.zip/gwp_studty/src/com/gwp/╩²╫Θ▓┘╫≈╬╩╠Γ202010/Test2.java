package com.gwp.数组操作问题202010;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/5
 * Description: 旋转数组的最小数字问题  原数组非递减排序   如旋转后为{3,4,5,1,2}，求最小值时间log(n) 二分法
 */

public class Test2 {
    public static int xuanzhuanmin(int[] arr){
        if (arr.length == 0) return 0;
        int first = 0;
        int last = arr.length - 1;
        while (first < last){
            int mid = (first + last) / 2;
            if (arr[first] < arr[last]){
                return arr[first];
            }
            if (arr[mid] > arr[last]){
                first = mid +1;
            }else if (arr[mid] < arr[last]){
                last = mid;
            }else {
                last--;
            }
        }
        return arr[first];
    }
    public static void main(String [] args){
        int[] test= {3,4,5,1,2};
        System.out.println(xuanzhuanmin(test));
    }
}
