package com.gwp.数组操作问题202010;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2021/1/13
 * Description: 股票问题，一个数组中元素表示每天的股票价钱，怎样买入、卖出赚最多。
 */

public class Test11 {
    //一次买卖操作 获取最大利润
    public static int printmax(int[] arr){
        int t= 0;
        int[] dp = new int[arr.length];
        if (arr.length <=1 || arr ==null) return 0;
        int minprice=arr[0];
        for (int i=1;i<arr.length;i++){
            dp[i] = Math.max(dp[i-1],arr[i]-minprice);
            minprice = Math.min(minprice,arr[i]);
        }
        return dp[arr.length-1];
    }
    // 多次买卖获取最大利润
    public static int maxprofit(int[] prices){
        if (prices == null || prices.length == 0){
            return 0;
        }
        //0表示未持有股票，1表示持有股票
        int[][] dp = new int[prices.length][2];
        dp[0][0] = 0;dp[0][1] = - prices[0];
        for (int i=1;i<prices.length;i++){
            //第i天不持有股票情况  要么i-1天未只有股票，或者i-1天持有股票，然后第i天卖了
            dp[i][0] = Math.max(dp[i-1][0],dp[i-1][1]+prices[i]);
            //第i天持有股票的两种可能，第i-1天持有股票，或者第i-1天
            dp[i][1] = Math.max(dp[i-1][i],dp[i-1][0]-prices[i]);
        }
        //取第i天持有和不持有股票中的最大值为最大收益
        return Math.max(dp[prices.length-1][0],dp[prices.length-1][1]);
    }
    public static void main(String [] args){
        int[] test = {7,1,5,3,6,4};
    }
}
