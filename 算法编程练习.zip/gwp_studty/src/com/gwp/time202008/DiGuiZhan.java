package com.gwp.time202008;

import java.util.Stack;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/9/1
 * Description: 使用一个递归函数让栈逆序取出
 */

public class DiGuiZhan {
    public static  int getandremovelelment(Stack<Integer> stack){
        int result = stack.pop();
//        System.out.println("每次递归前的值："+result);
        if (stack.empty()){
            return result;
        }else {
            int tail = getandremovelelment(stack);
//            System.out.println(" 每次递归后值："+result);
            stack.push(result);
            return tail;
        }
    }
    public static void  stackreverse(Stack<Integer> stack){
        if (stack.empty()){
            return;
        }
        int tmp  =  getandremovelelment(stack);
        System.out.println(" 每次递归前压入值："+tmp);
        stackreverse(stack);
        System.out.println(" 每次递归后压入值："+tmp);
        stack.push(tmp);
    }
    public static void main(String [] args){
        Stack<Integer> stack = new Stack<Integer>();
        for (int i=0;i<5;i++){
            stack.push(i);
        }
//        getandremovelelment(stack);
//        System.out.println(getandremovelelment(stack));
        stackreverse(stack);
//        while (!stack.isEmpty()){
//            System.out.println(stack.pop());
//        }
    }
}
