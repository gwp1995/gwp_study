package com.gwp.time202008;

import java.util.Scanner;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/8/26
 * Description:算法编程测试题目
 */

public class TestStudyCode {
    /**
     * 回文子串，给定字符串，最少操作次数后变成回文子串
     */
    static int huiwen(String a){
        //反转a字符串，然后求a串与反转串的最大公共子序列。得出最大回文串长度。
        String b = new  StringBuilder(a).reverse().toString();
//        System.out.println("打印反转后的字符串："+b);
        int[][] arr = new int[a.length()+1][a.length()+1];
        for ( int i=1;i<=a.length();i++){
            arr[i][0] = 0;
            for (int j=1;j<=b.length();j++){
                arr[0][j] = 0;
                if (a.charAt(i-1) == b.charAt(j-1)){
                    arr[i][j] = arr[i-1][j-1] + 1;
                }
                if (a.charAt(i-1) != b.charAt(j-1)){
                    arr[i][j] = Math.max(arr[i-1][j],arr[i][j-1]);
                }
//                System.out.println("打印记录数组值："+"i-"+i+" j-"+j+" "+arr[i][j]);
            }
        }
        return a.length()- arr[a.length()][b.length()];
    }
    public static void main(String [] args){
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext()){
            String test = scanner.nextLine();
            System.out.println("最少操作次数："+huiwen(test));
        }

    }
}
