package com.gwp.time202008;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/8/27
 * Description:算法基础 字符移位
 */

public class ZiFuYiWei {
    public static char[]  zifuyiwei(char[] a){
        int j=0;
        int tt=a.length-1;
        while(tt>=0){
            if (Character.isLowerCase(a[tt])){
                j=tt;
                break;
            }
            tt--;
        }
        for (int i=a.length-1;i>=0;i--){
            if (Character.isUpperCase(a[i]) && i < j){
                for (int x=i;x<j;x++){
                    char temp= a[x];
                    a[x]=a[x+1];
                    a[x+1]=temp;
                }
                j--;
            }
        }
        return a;
    }
    //简单方法，直接把原字符替换2次相加
    public static String getresult(String a){
        a.equals("");
        return   a.replaceAll("[A-Z]","") + a.replaceAll("[a-z]","");
    }
    public static void main(String [] args){
        Scanner scanner = new Scanner(System.in);
//        while (scanner.hasNext()){
//            char[] test = scanner.nextLine().toCharArray();
//            System.out.println(zifuyiwei(test));
//        }
        String test1 = scanner.next();
        System.out.print( getresult(test1) );
    }
}
