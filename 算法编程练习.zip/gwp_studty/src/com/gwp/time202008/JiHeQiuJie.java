package com.gwp.time202008;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/8/28
 * Description:p为给定的二维平面整数点集，定义p中某点，如果满足p中任意点都不在x的右上方，则称其为最大的。求出所有最大的点的集合。
 */

public class JiHeQiuJie {
    public static void main(String [] args){
        Scanner scanner = new Scanner(System.in);
        int n = 5;
        ArrayList<HashMap> arrayList = new ArrayList<HashMap>();
        HashMap map = new HashMap<Integer,Integer >();
        while (n>0){
            int x = scanner.nextInt();
            int y = scanner.nextInt();
            map.put(x,y);
            arrayList.add(map);
            n--;
        }
        if (arrayList.iterator().hasNext()){
            System.out.println(arrayList.iterator().next());
        }
    }
}
