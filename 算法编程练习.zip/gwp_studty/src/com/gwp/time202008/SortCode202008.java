package com.gwp.time202008;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader;

import java.util.Arrays;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/8/24
 * Description:
 */

public class SortCode202008 {
    /**
     * 冒泡排序 稳定排序  时间复杂度 O(n^2)
     */
    static int [] bubblesort(int [] a){
        for (int i=0;i<a.length;i++){
            int tt=0;
            for (int j=0;j <a.length -i-1;j++){
                if (a[j+1] < a[j]){
                    int tmp = a[j+1];
                    a[j+1] = a[j];
                    a[j] = tmp ;
                    tt=1;
                }
            }
            if (tt == 0){
                break;
            }
        }
        return  a;
    }

    /**
     * 选择排序  不稳定排序  时间复杂度O(n^2)
     */
    static  int[] selectionsort(int [] a){
        for (int i = 0;i< a.length;i++){
            int max = i;
            for (int j=i;j<a.length;j++){
                if (a[j] > a[max]) {
                    max = j;
                }
            }
            int tmp = a[max];
            a[max] = a[i];
            a[i] = tmp;
        }
        return a;
    }

    /**
     * 插入排序  稳定排序 时间复杂度O(n^2)
     */
    static int [] insertsort(int [] a){
        for (int i =1; i < a.length;i++){
            for (int j=i;j > 0;j--){
                if (a[j] < a[j-1]){
                    int tmp = a[j-1];
                    a[j-1] = a[j];
                    a[j] = tmp;
                }
            }
        }
        return a;
    }

    /**
     * 希尔排序 不稳定排序 时间复杂度O(nlogn)
     */
    static int[] shellsort(int[] a){
        int stap = a.length / 2;
        while (stap > 0){
            for (int i = 0;i < a.length;i = i + stap){
                for (int j = i;j < a.length; j = j + stap){
                    if (j - stap >=0 && a[j-stap] > a[j]){
                        int tmp = a[j];
                        a[j] = a[j-stap];
                        a[j-stap] = tmp;
                    }
                }
            }
            stap = stap / 2;
        }
        return a;
    }

    /**
     * 归并排序 分而治之  稳定排序 时间复杂度O(nlogn)
     */
    static  void mergesort(int [] a,int left,int right,int[] tmp ){
        if (right > left ){
            int mid = (left + right)/2;
            mergesort(a,left,mid,tmp);
            mergesort(a,mid+1,right,tmp);
            sort(a,tmp,left,mid,right);
        }
    }
    static void sort(int[] a,int[] b,int left,int mid,int right){
        int i=left;
        int j=mid +1;
        int x =0;
        while (i <= mid && j <= right ){
            if (a[i] < a[j]){
                b[x++] = a[j++];
            }else {
                b[x++] = a[i++];
            }
        }
        while (i <= mid) {
            b[x++] = a[i++];
        }
        while (j <= right){
            b[x++] = a[j++];
        }
        x=0;
        while (left <= right){
            a[left++] = b[x++];
        }
    }

    /**
     * 快速排序 稳定排序 时间复杂度0(nlogn)
     */
    static void  quicksort(int [] a,int left,int right){
      if (right > left) {
          int pivot = left;
          int i = left;
          int j = right;
          while (j > i) {
              while (a[j] >= a[pivot] && j > i) {
                  j--;
              }
              while (a[i] <= a[pivot] && j > i) {
                  i++;
              }
              if (i != j) {
                  int tmp = a[j];
                  a[j] = a[i];
                  a[i] = tmp;
              }
          }
          int tt = a[i];
          a[i] = a[pivot];
          a[pivot] = tt;
          quicksort(a, left, i - 1);
          quicksort(a, i + 1, right);
      }
    }

    /**
     * 堆排序 不稳定排序 时间复杂度O(nlogn)
     */
    static void heapsort(int [] a){
      for (int i = a.length/2 -1;i >=0;i--){
          adjustheap(a,i,a.length);
      }
      for (int j=a.length-1;j>0;j--){
          swap(a,0,j);
          adjustheap(a,0,j);
      }
    }
    //构建大顶堆
    static void adjustheap(int[] a,int i,int length){
        int tmp = a[i];
        System.out.print("打印tmp的值："+tmp);
        for (int k=2*i+1;k<length;k=2*k+1){
            if (k < length-1 && a[k] < a[k+1] ){
                k++;
            }
            System.out.println("  打印a[i]的值："+a[i]);
            if (a[k] > tmp){
                a[i] = a[k];
                i = k;
            }else {
                break;
            }
        }
        a[i] = tmp;
    }
  //元素交换函数
    static void swap(int[] a,int x,int y){
        int temp = a[x];
        a[x] = a[y];
        a[y] = temp;
    }
    public static void main(String [] args){
        int [] test1 = {81,94,11,96,12,35,17,95,28,58,41,75,15};
        int[] tmp = new int[test1.length];
//        bubblesort(test1);
//        selectionsort(test1);
//        insertsort(test1);
//        shellsort(test1);
//       mergesort(test1,0,test1.length-1,tmp);
//        quicksort(test1,0,test1.length-1);
        heapsort(test1);
        System.out.print(Arrays.toString(test1));
    }
}
