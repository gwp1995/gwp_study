package com.gwp.time202008;

import java.util.Arrays;
import java.util.Scanner;

import static java.lang.Math.pow;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/8/28
 * Description:
 */

public class Main {
    public static void reorderarray(int[] arr) {
      int [] a = new int[arr.length];
      int [] b = new int[arr.length];
      int j = 0;
      int x = 0;
      for (int i = 0;i < arr.length;i++){
          if (arr[i] % 2 != 0){
              a[x] = arr[i];
              x++;
          }else {
              b[j] = arr[i];
              j++;
          }
      }
      int tt =0;
      int yy = arr.length-1;
      while (x >0){
          arr[tt] = a[tt];
          tt++;
          x--;
      }
      while (j >0){
          arr[yy] = b[j-1];
          yy--;
          j--;
      }
    }
    public static void main(String [] args){
            Scanner scanner = new Scanner(System.in);
            int n = scanner.nextInt();
            int i =0;
            int [] a = new int[n];
            while (n >0){
                a[i] = scanner.nextInt();
                n--;
                i++;
            }
            reorderarray(a);
            System.out.print(Arrays.toString(a));


    }
}
