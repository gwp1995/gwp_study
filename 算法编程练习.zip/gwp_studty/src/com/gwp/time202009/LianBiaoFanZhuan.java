package com.gwp.time202009;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/9/2
 * Description: 链表反转并输出链表表头
 */
 class ListNode{
    int  val;
    ListNode next = null;
    ListNode(int val){
        this.val = val;
    }
}
public class LianBiaoFanZhuan {
    public static ListNode reverselist(ListNode head){
        int tmp= 0;
        while (head.next != null){
            tmp = head.next.val;
            head = head.next;
        }
        return head;
    }
    public static void main(String [] args){

    }
}
