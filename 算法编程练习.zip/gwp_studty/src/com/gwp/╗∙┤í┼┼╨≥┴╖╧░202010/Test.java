package com.gwp.基础排序练习202010;

import java.util.Arrays;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/10/25
 * Description:基础排序算法练习
 */

public class Test {

    //冒泡排序
    public static void  maopao(int[] arr){
        Boolean tag = false;
        for (int i=0;i<arr.length-1;i++){
            for (int j=0;j<arr.length-i-1;j++){
                if (arr[j] > arr[j+1]){
                    int temp = arr[j+1];
                    arr[j+1] = arr[j];
                    arr[j] = temp;
                    tag = true;
                }
            }
            if (tag == false){
                break;
            }
        }
    }

    //快速排序
    public static void quicksort(int[] arr,int left,int right){
        if (right > left){
            if (arr.length ==0 )
                return;
            int povit = arr[left];
            int i=left;
            int j = right;
            while (j > i){
                while (arr[j] >= povit && j > i){
                    j--;
                }
                while (arr[i]<= povit && i < j){
                    i++;
                }
                if (i != j){
                    int temp = arr[j];
                    arr[j] = arr[i];
                    arr[i] = temp ;
                }
            }
            int temp = arr[i];
            arr[i] = povit;
            arr[left] = temp;
            quicksort(arr,left,i-1);
            quicksort(arr,i+1,right);
        }
    }
    //插入排序
    public static void insertsort(int[] arr){
     for (int i=1;i<arr.length;i++){
         for (int j=i;j>0;j--){
             if (arr[j] < arr[j-1]){
                 int temp = arr[j];
                 arr[j] = arr[j-1];
                 arr[j-1] = temp;
             }
         }
     }
    }
    //希尔排序
    public static void  xiersort(int[] arr,int left,int right){
        int stap = (left + right) / 2;
        while (stap > 0){
            for (int i= stap;i< arr.length;i = i + stap){
                for (int j=i;j>0;j = j -stap){
                    if (arr[j] < arr[j-stap] && j >= stap){
                        int temp = arr[j];
                        arr[j] = arr[j-stap];
                        arr[j-stap] = temp;

                    }
                }
            }
            stap = stap /2 ;
        }
    }
    //选择排序
    public static void  selectsort(int[] arr){
        if (arr.length == 0)
            return;
        for (int i=0;i<arr.length;i++){
            int min = i;
            for (int j=i+1;j<arr.length;j++){
                if (arr[j] < arr[min]){
                    min = j;
                }
            }
            int temp = arr[min];
            arr[min] = arr[i];
            arr[i] = temp;
        }
    }
    public static void main(String [] args){
        int [] test1 = {81,94,11,96,12,35,17,95,28,58,41,75,15};
//        quicksort(test1,0,test1.length-1);
//        insertsort(test1);
//        xiersort(test1,0,test1.length-1);
//        maopao(test1);
        selectsort(test1);
        System.out.println(Arrays.toString(test1));
    }
}
