package com.gwp.栈操作问题;

import java.util.Stack;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/12
 * Description: 输入2个整数序列，第一个序列表示压栈的顺序，判断第二个序列是否可能为该栈的弹出顺序
 */

public class Test1 {
    public static boolean ispoporder(int[] pusha,int[] popa){
        if (pusha.length == 0) return false;
        Stack<Integer> stack = new Stack<>();
        int i=0;
        for (int j=0;j< pusha.length;j++){
            stack.push(pusha[j]);
            while (!stack.isEmpty() && stack.peek() == popa[i]){
                stack.pop();
                i++;
            }
        }
        return stack.isEmpty();
    }
    public static void main(String [] args){
        int[] push={1,2,3,4,5};
        int[] pop={4,3,5,1,2};
        System.out.println(ispoporder(push,pop));
    }
}
