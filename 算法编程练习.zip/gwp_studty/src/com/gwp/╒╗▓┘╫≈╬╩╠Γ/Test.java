package com.gwp.栈操作问题;

import java.util.Stack;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/2
 * Description: 用两个栈来实现一个队列，完成队列的push，pop
 */

public class Test {
    Stack<Integer> stack1 = new Stack<>();
    Stack<Integer> stack2 = new Stack<>();
    public void  push(int node){
        stack1.push(node);
        stack2.push(stack1.pop());
    }
    public int pop(){
        return stack2.pop();
    }
    public static void main(String [] args){
    }
}
