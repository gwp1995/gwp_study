package com.gwp.动态规划问题202010;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/8/11
 * Description:钢条切割问题，给定长度钢条，使其切割多段后，对应价格总值最大  ---区间型动态规划问题
 */

public class GangTiaoQieGe {
    public static void maxqiege(int n,int [] p,int [] c,int [] rec){
        c[0] = 0;
        int max = 0;
        for (int j=1;j <= n;j++){
            max = p[j];
            rec[j] = j;
            for (int i=1;i <= j-1;i++){
                if ((p[i]+c[j-i]) > max){
                    max = p[i] + c[j-i];
                    rec[j] = i;
                }
            }
            c[j] = max;
        }
    }
    //遍历记录数组，打印切割位次
    public static void  printpoint(int [] rec){
        for (int i = rec.length-1;i >=0;i = i - rec[i]){
            if (rec[i] == i){
                System.out.println(rec[i]);
                break;
            }else {
                System.out.println(rec[i]);
            }
        }
    }
    public static void main(String [] args){
       int [] p = {0,1,5,8,9,10,17,17,20,24,24};
       int n = 10;
       int [] c  = new int[n+1];
       int [] rec = new int[n+1];
       maxqiege(n,p,c,rec);
       System.out.println("最大价格和："+c[n]);
       printpoint(rec);
    }
}
