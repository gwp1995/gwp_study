package com.gwp.动态规划问题202010;

import java.util.Scanner;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/8/8
 * Description:求A串变成B串所需的最小编辑值（只包括，插入、删除、替换操作） --动态规划问题
 */

public class MinBianJiJuLi {
    public static  int minbiaojjijuli(String a,String b,int [][] c){
        int min = 0;
        //初始化二位数据第一行和第一列的值
        for (int i= 0;i<= a.length();i++){
            c[i][0] = i;
        }
        for (int j=0;j <=b.length();j++){
            c[0][j] = j;
        }
        for (int i =1;i <= a.length();i++){
            for (int j=1;j <=b.length();j++){
                 if (a.charAt(i-1) == b.charAt(j-1)){
                     min = Math.min(c[i-1][j]+1,c[i][j-1]+1);
                     c[i][j] = Math.min(min,c[i-1][j-1]);
                 }else{
                     min = Math.min(c[i-1][j]+1,c[i][j-1]+1);
                     c[i][j] = Math.min(min,c[i-1][j-1] +1);
                 }
            }
        }
        return c[a.length()][b.length()];
    }
    public static void main(String [] args){
        Scanner scanner = new Scanner(System.in);
        String a = scanner.next();
        String b = scanner.next();
        int [][] c = new int[a.length()+1][b.length()+1];
        int tt = minbiaojjijuli(a,b,c);
        System.out.println("需要编辑的最小次数："+ tt);
    }
}
