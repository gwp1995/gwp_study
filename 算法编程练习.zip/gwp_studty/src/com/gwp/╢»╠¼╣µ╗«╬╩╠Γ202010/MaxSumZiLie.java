package com.gwp.动态规划问题202010;


/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/7/2
 * Description:求最大子序列和问题
 */

public class MaxSumZiLie {
    public static int maxsubsum(int [] a){
     int maxsum = 0;
     int thissum = 0;
     for(int j = 0; j < a.length ;j++){
         thissum += a[j];
         if (thissum > maxsum){
             maxsum = thissum;
         }else if  (thissum < 0){
             thissum = 0;
         }
     }
     return  maxsum;
    }
    public static void main(String [] args){
        int [] a = {1,2,-6,-8,4,7,9,-5,3};
        int y =maxsubsum(a);
        System.out.println(y);

    }
}
