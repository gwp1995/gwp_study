package com.gwp.动态规划问题202010;

import java.util.Arrays;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/10/29
 * Description: 求一个整型数组的递增子序列 如 4,2,3,1,5 最大递增子序列为2,3,5
 */

public class MaxDiZendZiXuLie {

    public static int dp(int[] a,int[] b){
        if (a.length == 0 || b.length == 0) return 0;
        int[][] result = new int[a.length+1][b.length+1];
        for (int i=1;i<=a.length;i++){
            for (int j=1;j<=b.length;j++){
                result[0][j] = 0;
                result[i][0] = 0;
                if (a[i-1] == b[j-1]){
                    result[i][j] = result[i-1][j-1] + 1;
                }else{
                    result[i][j] = Math.max(result[i-1][j],result[i][j-1]);
                }
                System.out.println("打印每次result的值： "+result[i][j]+" 角标i的值："+i+" 角标j的值："+j);
            }
        }
        return result[a.length][b.length];
    }
    public static void main(String [] args){
        int[] tt = {1,2,3,4,5};
        int[] test = {4,2,3,1,5};
//        int[] tt = Arrays.copyOfRange(test,0,test.length-1);
//         Arrays.sort(test);
         int len = dp(tt,test);
        System.out.println(len);
    }
}
