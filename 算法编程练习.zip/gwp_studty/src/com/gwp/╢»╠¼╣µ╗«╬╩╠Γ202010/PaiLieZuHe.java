package com.gwp.动态规划问题202010;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/21
 * Description: 输入一个字符串，按字典顺序打印该字符串的所有排列，如输入"abc" ,则排列所有字符串abc,acb,bac,bca,cab,cba
 */

public class PaiLieZuHe {
    public static void huisu(HashSet<String> set,char[] arr,int k){
        if (k == arr.length-1){
            set.add(new String(arr));
            return;
        }
        for (int i=k;i<arr.length;i++){
            swap(arr,i,k);
            huisu(set,arr,k+1);
            swap(arr,i,k);
        }
    }
    public static void swap(char[] arr,int i,int j){
        char temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    public static ArrayList<String> permutation(String str){
        ArrayList<String> list = new ArrayList<>();
        HashSet<String> set = new HashSet<>();
        char[] arr = str.toCharArray();
        huisu(set,arr,0);
        list.addAll(set);
        Collections.sort(list);
        return  list;
    }
    public static void main(String [] args){
        String str = "abc";
        ArrayList<String> list = permutation(str);
        System.out.println(list);
    }
}
