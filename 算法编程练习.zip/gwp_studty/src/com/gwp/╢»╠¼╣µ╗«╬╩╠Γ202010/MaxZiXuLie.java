package com.gwp.动态规划问题202010;

import java.util.Scanner;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/8/6
 * Description:最长公共子序列问题 ---动态规划
 */

public class MaxZiXuLie {
    //构建bp表，找到最大公共子序列值，存入数组中
    public static  void maxzixulie(String a,String b,int [][] c,String [][] rec){
        for (int i = 1;i<=a.length();i++){
            for (int j= 1;j<=b.length();j++){
                c[i][0] = 0;
                c[0][j] = 0;
                if (a.charAt(i-1) == b.charAt(j-1)){
                    c[i][j] = c[i-1][j-1] + 1;
                    rec[i][j] = "LU";
                } else if (c[i-1][j] >= c[i][j-1]) {
                    c[i][j] = c[i-1][j];
                    rec[i][j] = "U";
                }else{
                    c[i][j] = c[i][j-1];
                    rec[i][j] = "L";
                }
            }
        }
    }
    //遍历记录数组rec，逆推出最大子序列的具体值
    public static void printlcs(String [][] rec,String a, int i,int j){
        if (i ==0 || j ==0){
            return;
        }
        if (rec[i][j] == "LU"){
            printlcs(rec,a,i-1,j-1);
            System.out.print(a.charAt(i-1));
        }
        else if (rec[i][j] == "U"){
            printlcs(rec,a,i-1,j);
        }
        else if (rec[i][j] == "L"){
            printlcs(rec,a,i,j-1);
        }
    }
    public static void main(String [] args){
        Scanner scanner = new Scanner(System.in);
        String a = scanner.next();
        String b = scanner.next();
        int [][] c = new int [a.length()+1][b.length()+1];
        String [][] rec = new String[a.length()+1][b.length()+1];
        maxzixulie(a,b,c,rec);
        printlcs(rec,a,a.length(),b.length());
    }
}
