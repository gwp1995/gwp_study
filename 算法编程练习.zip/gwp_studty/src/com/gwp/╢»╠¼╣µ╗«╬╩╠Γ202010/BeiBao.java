package com.gwp.动态规划问题202010;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/8/5
 * Description:0-1 背包问题求解 ---动态规划问题
 */

public class BeiBao {
    public static int getMaxValue(int [] weight,int [] value,int w,int n){
        int [][] table = new int[n+1][w+1];//创建二位数组，横列标示物品的价值，竖列表示物品的重量
        for (int i =1;i <= n;i++){ //物品个数循环
            for (int j=1;j<=w;j++){ //背包大小
                if (weight[i] > j){

                    //当前物品i的重量比背包容量j大，装不下
                    table[i][j] = table[i-1][j];
                }else{
                    //装的下，那就取 max{装物品i，不装物品i}
                    table[i][j] = Math.max(table[i-1][j],table[i-1][j- weight[i]] + value[i]);
                }
            }
        }
        return table[n][w];
    }
    public static void main(String [] args){
       int n = 5, w = 10;
       int [] value = {0,6,3,5,4,6};
       int [] weight = {0,2,2,6,5,4};
       System.out.println(getMaxValue(weight,value,w,n));
    }
}
