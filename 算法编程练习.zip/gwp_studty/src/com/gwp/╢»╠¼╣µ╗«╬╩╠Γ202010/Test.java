package com.gwp.动态规划问题202010;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2021/1/19
 * Description:
 */

public class Test {
    public static int maxsun(int[] arr){
        if (arr.length == 0 || arr == null) return 0;
        int sum = arr[0];
        int result=arr[0];
        for (int i=1;i<arr.length;i++){
            sum = Math.max(sum + arr[i],arr[i]);
           result = Math.max(sum,result);
        }
        return result;
    }
    public static int maxprice(int[] arr){
        if (arr.length == 0 || arr == null) return 0;
        int[] dp = new int[arr.length];
        int minprice=arr[0];
        for (int i=1;i<arr.length;i++){
            dp[i] = Math.max(dp[i-1],arr[i]-minprice);
            minprice = Math.min(arr[i],minprice);
        }
        return dp[arr.length-1];
    }
    public static void main(String [] args){
        int[] test = {1,2,-6,-8,4,7,9,-5,3};
        int[] test1 = {2,1,3,4,5,7,6};
//        System.out.println(maxsun(test));
        System.out.println(maxprice(test1));
    }
}
