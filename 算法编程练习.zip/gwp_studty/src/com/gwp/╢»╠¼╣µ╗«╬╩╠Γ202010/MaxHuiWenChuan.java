package com.gwp.动态规划问题202010;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/10/31
 * Description: 最长回文子串
 */

public class MaxHuiWenChuan {
    public static String maxhuiwenchuan(String s){
        int start=0;
        int maxl=1;
        int[][] result = new int[s.length()][s.length()];
        for (int i=0;i<s.length();i++){
            result[i][i] = 1;
        }
        for (int j=1;j<s.length();j++){
            for (int i=0;i<j;i++){
                if (s.charAt(i) != s.charAt(j)){
                    result[i][j] = 0;
                }else{
                    if (j-i+1 < 3){
                        result[i][j] = 1;
                    }else{
                        result[i][j] = result[i+1][j-1];
                    }
                }
                if (result[i][j] == 1 && (j-i+1) > maxl){
                    start = i;
                    maxl = j-i+1;
                }
            }
        }
        return  s.substring(start,start + maxl);
    }
    public static String longestpalindrome(String s){
        int len = s.length();
        if (len == 0 || len == 1) return s;
        int[][] dp = new int[len][len];
        int start = 0;
        int maxlen = 1;
        for (int i=0;i<len;i++){
            dp[i][i] = 1;
            if (i < len -1 && s.charAt(i) == s.charAt(i+1)){
                dp[i][i+1] = 1;
                start = i;
                maxlen = 2;
            }
        }
        for (int l=3;l<=len;l++){
            for (int i=0;i<=len-l;i++){
                int j= l + i -1;
                if (s.charAt(i) == s.charAt(j) && dp[i+1][j-1] == 1){
                    dp[i][j] = 1;
                    start = i;
                    maxlen = l;
                }
            }
        }
        return s.substring(start,start + maxlen);
    }
    public static void main(String [] args){
    }
}
