package com.gwp.动态规划问题202010;

import java.util.Arrays;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/7/9
 * Description:
 */

public class SortCode {


    static int [] bubblesort(int [] a){
        for (int i = 0; i < a.length  ;i++){
            int tt = 0;
            for (int j=0;j < a.length -1 - i;j++){
                if (a[j+1] < a[j]){
                    int tmp = a[j+1];
                    a[j+1] = a[j];
                    a[j] = tmp;
                    tt = 1;
                }
            }
            if (tt == 0){
                break;
            }
        }
        return a;
    }
     /**
     * 插入排序
     * */
     static int [] insertionSort(int[] a){
        for (int i = 1; i< a.length; i++){
            for (int j = i; j >0 ; j-- ){
                if (a[j-1] > a[j]){
                    int tmp = a[j];
                    a[j] = a[j-1];
                    a[j-1] = tmp;
                }
            }
        }
      return  a;
    }
    /**
     * 希尔排序---减缩增量排序
     */
    static int [] HillSort(int [] a){

        int step = a.length / 2;
        while (step > 0){
            for (int i = step; i < a.length; i++){
                for (int j = i; j-step >=0 ; j--){
                    if (a[j-step] > a[j]){
                        int tmp = a[j];
                        a[j] = a[j-step];
                        a[j-step] = tmp;
                    }
                }
            }
            step = step/2;
        }

        return a;
    }

    /**
     *
     *  堆排序 --1 建堆 2--堆顶元素与堆尾元素交换
     */
    static void HeapSort(int [] arr){
        //构造大顶堆
        for (int i = arr.length/2-1 ;i >=0 ; i--){
            adjustHeap(arr,i,arr.length);
        }
        //调整堆结构，交换堆顶与堆尾元素
        for (int j = arr.length-1;j >=0;j--){
            swap(arr,0,j);
            adjustHeap(arr,0,j);
        }
    }
    static void adjustHeap(int [] arr,int i, int length){
        int temp = arr[i];
        for (int k = 2*i +1;k<length;k = 2*k +1){
            if (k+1 < length && arr[k] < arr[k+1]){
                k++;
            }
            if (arr[k] > temp){
                arr[i] = arr[k];
                i = k;
            }else{
                break;
            }
        }
        arr[i] = temp;
    }
    static void swap(int [] arr,int a,int b){
        int temp = arr[a];
        arr[a] = arr[b];
        arr[b] = temp;
    }

    /**
     *
     * 归并排序  1- 拆分数组 2-合并两个有序的数组
     */
    static void sort(int [] a){
        int [] temp = new int[a.length];
        mergesort(a,0,a.length-1,temp);

    }
    static void mergesort(int [] a,int left,int right,int [] temp){

        if (left < right){//将原数组拆分成一个个数组，这样就成局部有序数组，之后再合并
            System.out.println("进入递归进行数组拆分！！");
            int mid = (left + right)/2;
            mergesort(a,left,mid,temp);//左边归并排序
            mergesort(a,mid+1,right,temp);//右边归并排序
            merge(a,left,mid,right,temp);//合并2个有序数组
        }
    }
    static void merge(int [] a,int left,int mid,int right,int [] temp){
        System.out.println("进入合并，开始合并数组！！！");
        int i = left;
        int j = mid +1;
        int t = 0 ;
        while (i <= mid && j <= right){
            if (a[i] <= a[j]){
                temp[t] = a[i];
                t++;
                i++;
            }else {
                temp[t] = a[j];
                t++;
                j++;
            }
        }
        while (i <= mid){
            temp[t] = a[i];
            t++;
            i++;
        }
        while (j <= right){
            temp[t] = a[j];
            t++;
            j++;
        }
        t = 0;
        while (left <= right){
            a[left] = temp[t];
            left++;
            t++;
        }
    }

    /**
     *
     * 快速排序
     */
    static  void qucik_sort(int[] arr,int left,int right){
        if (left < right){
            int i = left;
            int j = right;
            int x = arr[left];
            while (i < j) {
                while (i < j && arr[j] >= x){
                    j--;
                }
                while (i < j && arr[i] <= x){
                    i++;
                }
                if (i != j) { swap(arr,i,j); }
            }
            swap(arr,i,left);
            qucik_sort(arr,left,i-1);
            qucik_sort(arr,i+1,right);
        }
    }

    public static void main(String [] args){
//       int [] test ={34,8,64,51,32,21};
       int [] test1 = {81,94,11,96,12,35,17,95,28,58,41,75,15};
//       int [] test2 = {81,94,11,96,12,35,17,95,28,58,41,75,15};
//       sort(test2);
//         bubblesort(test1);
//        qucik_sort(test1,0,test1.length-1);
//       System.out.println("执行完归并排序----");
       HeapSort(test1);
//       System.out.println(Arrays.toString( insertionSort(test)));
//       System.out.println(Arrays.toString(HillSort(test1)));
//       System.out.println(Arrays.toString(test1));
//       System.out.println(Arrays.toString(test2));
       System.out.println(Arrays.toString(test1));
    }
}
