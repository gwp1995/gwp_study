package com.gwp.动态规划问题202010;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/8/7
 * Description:最大公共子串问题 --动态规划
 */

public class MaxZiChuan {
    public  static Map<String, Integer> maxzichuan(String a, String b, int [][] c){
        Map<String,Integer> map = new HashMap<>();
        int pmax = 0, lmax = 0;
        for (int i=1;i <= a.length();i++){
            for (int j=1;j <= b.length();j++){
                c[0][j] = 0;
                c[i][0] = 0;
                if (a.charAt(i-1) == b.charAt(j-1)){
                    c[i][j] = c[i-1][j-1] + 1;
                    if (c[i][j] > lmax){
                        lmax = c[i][j];
                        pmax = i;
                    }
                }else{
                    c[i][j] = 0;
                }
            }
        }
        map.put("pmax",pmax);
        map.put("lmax",lmax);
        return map;
    }
    public static void main(String [] args){
        Scanner scanner = new Scanner(System.in);
        String a = scanner.next();
        String b = scanner.next();
        int [][] c = new int[a.length()+1][b.length()+1];
        Map<String,Integer> map = maxzichuan(a,b,c);
        System.out.println("pmax: "+ map.get("pmax"));
        System.out.println("lmax: "+ map.get("lmax"));
        for (int i = (map.get("pmax")- map.get("lmax")) ;i < map.get("pmax");i++){
            System.out.print(a.charAt(i));
        }
    }
}
