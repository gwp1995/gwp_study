package com.gwp.链表问题202010;

import java.awt.*;
import java.util.HashMap;
import java.util.List;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/17
 * Description:  输入一个复杂链表，每个节点中，一个指针指向下一个节点，一个特殊指针指向任意节点。返回结果为复制后的复杂链表
 *               的head
 */

class RandomListNode{
    int val;
    RandomListNode next;
    RandomListNode random;
    RandomListNode(int val){
        this.val = val;
    }
}

public class Test3 {
    public static RandomListNode Clone(RandomListNode phead){
        HashMap<RandomListNode,RandomListNode> map = new HashMap<>();
        RandomListNode p = phead;
        //建立新的链表节点，但是各个节点孤立没有确立连接关系
        while (p!=null){
            RandomListNode newnode = new RandomListNode(p.val);
            map.put(p,newnode);
            p = p.next;
        }
        // 建立映射关系
        p = phead;
        while (p!=null){
            RandomListNode node = map.get(p);
            node.next = (p.next == null)?null:map.get(p.next);
            node.random = (p.random == null)?null:map.get(p.random);
            p=p.next;
        }
        return map.get(phead);
    }
    public static void main(String [] args){

    }
}
