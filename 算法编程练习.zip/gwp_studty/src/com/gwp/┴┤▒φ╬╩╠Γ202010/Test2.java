package com.gwp.链表问题202010;

import java.util.List;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/5
 * Description: 合并两个有序链表
 */

class ListNode{
    int val;
    ListNode next=null;
    ListNode(int val){
        this.val = val;
    }
}

public class Test2 {
    public static ListNode merge(ListNode list1,ListNode list2){
        ListNode list = new ListNode(0);
        ListNode cur = list;
        while (list1 != null && list2 != null){
            if (list1.val < list2.val){
                cur.next = list1;
                list1 = list1.next;
            }else {
                cur.next = list2;
                list2 = list2.next;
            }
            cur = cur.next;
            System.out.println("==========="+cur.val);
        }
        if (list1 != null){
            cur.next = list1;
            System.out.println("---------"+cur.val);
        }
        if (list2 != null){
            cur.next = list2;
            System.out.println("+++++++++"+cur.val);
        }
        return list.next;
    }
    public  static  void  printlist(ListNode list){
        if (list == null) return;
        while (list != null){
            System.out.println("打印合并后的链表值："+list.val);
            list = list.next;
        }
    }

    // 递归写法
    public static  ListNode merge1(ListNode list1,ListNode list2){
        if (list1 == null)
            return list2;
        else if (list2 == null)
            return list1;
        else{
            if (list1.val < list2.val){
                list1.next = merge1(list1.next,list2);
                return list1;
            }else{
                list2.next = merge1(list1,list2.next);
                return list2;
            }
        }
    }
    public static void main(String [] args){
        ListNode t1 = new ListNode(1);
        ListNode t2 = new ListNode(3);
        ListNode t3 = new ListNode(5);
        t1.next = t2;
        t2.next = t3;
        ListNode y1 = new ListNode(2);
        ListNode y2 = new ListNode(4);
        ListNode y3 = new ListNode(6);
        y1.next = y2;
        y2.next = y3;
        ListNode list = merge1(t1,y1);
        printlist(list);
    }
}
