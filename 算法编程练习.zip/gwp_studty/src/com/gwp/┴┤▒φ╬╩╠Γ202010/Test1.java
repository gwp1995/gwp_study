package com.gwp.链表问题202010;

import sun.awt.image.ImageWatched;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/10/27
 * Description: 链表问题
 */

class LinkNode{
    int val;
    LinkNode next = null ;
   LinkNode(int x){
        this.val = x;
    }
        }
public class Test1 {
    //迭代法反转链表
    public static LinkNode reverse(LinkNode linkNode){
        LinkNode pre = null;
        LinkNode now = linkNode;
        while (now != null){
            LinkNode next = now.next;
            now.next = pre;
            pre = now;
            now = next;
        }
        return pre;
    }
    //递归方法反转链表
    public static LinkNode diguireverse(LinkNode linkNode){
        if (linkNode.next == null ) return linkNode;
        LinkNode next = linkNode.next;
        linkNode.next = null;
        LinkNode re = diguireverse(next);
        next.next = linkNode;
        return  re;
    }
    public static void main(String [] args){
        LinkNode t = new LinkNode(1);
        LinkNode t1 = new LinkNode(2);
        t.next = t1;
        LinkNode t2 = new LinkNode(3);
        t1.next = t2;
//        LinkNode test =  reverse(t);
        LinkNode test = diguireverse(t);
        while (test != null){
            System.out.println(test.val);
            test = test.next;
        }
    }
}
