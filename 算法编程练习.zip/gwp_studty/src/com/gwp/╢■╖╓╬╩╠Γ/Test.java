package com.gwp.二分问题;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2021/1/14
 * Description: 给定2个有序数组，求合并后数组的中位数
 */

public class Test {
    public static double findmidsortarr(int[] arr1,int[] arr2){
        int m = arr1.length;
        int n= arr2.length;
        //交换数组长度，然后遍历短的数据
        if (m > n){
            int[] temp = arr1;
            arr1 = arr2;
            arr2 = temp;
            int tmp = m;
            m = n;
            n = tmp;
        }
        int start = 0;
        int end = m;
        int mid = (m + n + 1) /2;
        while (start <= end){
            int i = (start + end) /2 ;
            int j = mid - i;
            if (i < end && arr1[i] < arr2[j-1]){
                //i 偏小，需要往右移动
                start = i + 1;
            }
            else if (i < end && arr1[i-1] > arr2[j]){
                // i偏大，需要往左移动
                end = i-1;
            }else {
                // i 刚好合适，或者达到了数组边界
                int maxleft;
                if (i == 0){
                    maxleft = arr2[j-1];
                }else if (j == 0){
                    maxleft = arr1[i-1];
                }else{
                    maxleft = Math.max(arr1[i-1],arr2[j-1]);
                }
                //如果是长度是奇数，中位数就是左半部最大值
                if ((m + n) % 2 == 1){
                    return maxleft;
                }
                int minright;
                if (i == m){
                    minright = arr2[j];
                }else if (j == n){
                    minright = arr1[i];
                }else{
                    minright = Math.min(arr1[i],arr2[j]);
                }
                //如果数组是偶数，则左侧最大值和右侧最小值的平均
                return (maxleft + minright) / 2.0;
            }
        }
        return 0.0;
    }
    public static void main(String [] args){
        int[] arr1 = new int[]{3,5,6,7,8,12,20};
        int[] arr2 = new int[]{1,10,17,18};
        System.out.println(findmidsortarr(arr1,arr2));
    }
}
