package com.gwp.幕客网剑指offer编程练习202010;

import java.util.ArrayList;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/10/22
 * Description: 从尾到头的顺序打印链表，返回一个arraylist
 */
 class  ListNode{
    int val;
    ListNode next ;

    ListNode(int val){
        this.val = val;
    }
}
public class Test4 {
     public ArrayList<Integer> printListfromToHead(ListNode listNode){
         ArrayList<Integer> arrayList = new ArrayList<>();
         ArrayList<Integer> result = new ArrayList<>();
         if (listNode == null) {
             return  new ArrayList<>();
         }
         if (listNode.next == null){
             return new ArrayList<>(listNode.val);
         }

         while (listNode.next != null){
             arrayList.add(listNode.val);
             listNode = listNode.next;
         }
         arrayList.add(listNode.val);
         for (int i=arrayList.size()-1;i >=0;i--){
             result.add(arrayList.get(i));
         }
         return result;
     }

     public static void main(String [] args){
         ListNode listNode = new ListNode(2);
         listNode.next = new ListNode(3);
         listNode = listNode.next;
         listNode.next = new ListNode(4);
         Test4 test4 = new Test4();
         System.out.println(test4.printListfromToHead(listNode));
     }
}
