package com.gwp.幕客网剑指offer编程练习202010;

import javax.swing.text.TabExpander;
import java.util.*;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/10/9
 * Description: 随机分组
 */

public class Test2 {
    public static ArrayList<ArrayList<Integer>> SuiJiFenZu(int k,int[] arr){
        if (arr.length <0 || arr == null || k<0 ) return new ArrayList<>();
        int len = arr.length;
        ArrayList<ArrayList<Integer>> arrayLists = new ArrayList<>();
        ArrayList<Integer> arrayList = new ArrayList<>();
        HashMap<Integer,List<Integer>> hashMap = new HashMap<>();
        for (int i=0;i<len;i++){
            //根据分组数k进行一个hash取值
            int hash = i % k;
            //将每个hash值作为map的key，如果value相同则添加到value对应的list数组中
            if (!hashMap.containsKey(hash)){
                List<Integer> tt = new ArrayList<>();
                tt.add(i);
                hashMap.put(hash,tt);
            }else {
                List<Integer> list = hashMap.get(hash);
                list.add(i);
                hashMap.put(hash,list);
//                System.out.println("打印每个hash集合对应的角标： "+hashMap);
            }
        }
        //遍历map，将每个value对应的list取出，丢到总集合中
        for (Map.Entry<Integer,List<Integer>> map: hashMap.entrySet()) {
            for (Integer yy:map.getValue()){
                arrayList.add(arr[yy]);
            }
            arrayLists.add(arrayList);
            arrayList.clear();
        }
        return arrayLists;
    }
    public static void main(String [] args){
        int[] test={0,1,2,3,4,5,6,7,8,9};
        ArrayList<ArrayList<Integer>> tt = SuiJiFenZu(3, test);
        for (ArrayList<Integer> arrayList: tt){
            System.out.println(arrayList);
        }
    }
}
