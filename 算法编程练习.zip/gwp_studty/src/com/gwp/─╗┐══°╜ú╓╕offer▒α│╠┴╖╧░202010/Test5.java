package com.gwp.幕客网剑指offer编程练习202010;

import java.util.*;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/10/23
 * Description:输入二叉树前序遍历和中序遍历结果，重建二叉树
 */

class TreeNode{
    int val;
    TreeNode left;
    TreeNode right;
    TreeNode(int x){
        this.val=x;
    }
}
public class Test5 {
    public static TreeNode reconstructtree(int[] pre,int[] in){

        if (pre.length == 0 || pre == null){
            return null;
        }
        int rootval = pre[0];
        if (pre.length == 1){
            return new TreeNode(rootval);
        }
        //找到根节点
        TreeNode root = new TreeNode(rootval);
        int rootindex = 0;
        for (int i=0;i<in.length;i++){
            if (root.val == in[i]){
                rootindex = i;
                break;
            }
        }
        //递归，假设root的左右子树已构建完毕，那么只要将左右子树按到root左右即可。
        root.left = reconstructtree(Arrays.copyOfRange(pre,1,rootindex+1),Arrays.copyOfRange(in,0,rootindex));
        root.right = reconstructtree(Arrays.copyOfRange(pre,rootindex+1,pre.length),Arrays.copyOfRange(in,rootindex+1,in.length));
        return root;
    }
    //递归遍历
    public static void preprint(TreeNode treeNode) {
        if (treeNode == null){
            return;
        }
//        System.out.print(treeNode.val);
        preprint(treeNode.left);
        preprint(treeNode.right);
        System.out.print(treeNode.val);
    }
    //非递归前序遍历
    public static void qianxubianli(TreeNode treeNode){
        Stack<TreeNode> stack = new Stack();
        ArrayList<Integer> arrayList = new ArrayList<>();
        while (treeNode != null || !stack .isEmpty()){
            while (treeNode != null){
                arrayList.add(treeNode.val);
//                System.out.print(treeNode.val);
                stack.push(treeNode);
                treeNode = treeNode.left;
            }
            if (!stack.isEmpty()){
               treeNode =  stack.pop();
               treeNode = treeNode.right;
            }
        }
    }
    //非递归中序遍历
    public static ArrayList zhongxubianli(TreeNode treeNode){
        ArrayList<Integer> arrayList = new ArrayList<>();
        Stack<TreeNode> stack = new Stack<>();
        if (treeNode == null){
            return arrayList;
        }
        while (treeNode != null || !stack.isEmpty()){
            while (treeNode != null){
                  stack.push(treeNode);
                  treeNode = treeNode.left;
            }
            if (!stack.isEmpty()){
                  treeNode = stack.pop();
                  arrayList.add(treeNode.val);
                  treeNode = treeNode.right;
            }
        }
        return arrayList;
    }
    //非递归后序遍历
    public static void houxubianli(TreeNode treeNode){
        ArrayList<Integer> arrayList = new ArrayList<>();
        Stack<TreeNode> stack = new Stack<>();
        while (treeNode != null || !stack.isEmpty()){
            while (treeNode != null ){
                stack.push(treeNode);
                treeNode = treeNode.left;
            }
            Boolean tag = true;
            TreeNode pre = null; //前驱节点
            while (!stack.isEmpty() && tag == true){
                treeNode = stack.peek();
                if (treeNode.right == pre){
                    treeNode = stack.pop();
                    arrayList.add(treeNode.val);
                    if (stack.isEmpty()){
                        return ;
                    }else {
                        pre = treeNode;
                    }
                }else {
                    treeNode = treeNode.right;
                    tag = false;
                }
            }
        }
    }
    //层次遍历
    public static void cengxubianli(TreeNode treeNode){
        LinkedList<TreeNode> linkedList = new LinkedList<>();
        linkedList.add(treeNode);
        while (!linkedList.isEmpty()){
            treeNode = linkedList.poll();
            System.out.println(treeNode.val);
            if (treeNode.left != null){
                linkedList.add(treeNode.left);
            }
            if (treeNode.right != null){
                linkedList.add(treeNode.right);
            }
        }
    }
    public static void main(String [] args){
        int[] pre = {1,2,4,7,3,5,6,8};
        int[] in = {4,7,2,1,5,3,8,6};
        TreeNode test = reconstructtree(pre,in);
//        preprint(test);
        qianxubianli(test);
        System.out.println(zhongxubianli(test));
        cengxubianli(test);
    }
}

