package com.gwp.幕客网剑指offer编程练习202010;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/10/24
 * Description:最大连续子序列和
 */

public class MaxzixulieSum {
    public static int maxsum(int[] arr){
        int maxsum = 0;
        int thissum = 0;
        for (int i=0;i< arr.length;i++){
            thissum = thissum + arr[i];
            if (thissum >= maxsum){
                maxsum = thissum;
            }
            if (thissum < 0){
                thissum = 0;
            }
        }
        return maxsum;
    }
    public static void main(String [] args){
        int[] test = {1,2,-3,4,-5,-6,7,8,-20,6,7};
        System.out.println(maxsum(test));
    }
}
