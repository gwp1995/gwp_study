package com.gwp.幕客网剑指offer编程练习202010;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/10/8
 * Description:  在一个二维数组中查找一个整数是否存在，该二维数组每一行从左到右递增，每一列从上到下递增
 */

public class Test1 {
    /**
     * 普通二分查找，逐行进行二分
     */
    public static Boolean Find(int target, int[][] arr) {
        int len1 = arr.length;
        if (arr.length == 0 || arr == null) return false;
        for (int i = 0; i < len1; i++) {
            int low = 0;
            int hight = arr[i].length - 1;
            while (low <= hight) {
                int mid = (low + hight) / 2;
                if (arr[i][mid] > target) {
                    hight = mid - 1;
                }
                if (arr[i][mid] < target) {
                    low = mid + 1;
                } else {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 利用矩阵特性 从右上角或者左下角进行对比搜索
     */
    public static Boolean Find2(int target, int[][] arr) {
        int row = 0;
        int col = arr[0].length - 1;
        while (row <= arr.length - 1 && col >= 0) {
            if (target == arr[row][col]) {
                return true;
            }
            else if (target > arr[row][col])
                row++;
            else
                col--;
        }
        return false;
    }

    public static void main(String[] args) {
        int[][] test = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        System.out.println(Find(4, test));
        System.out.println(Find2(4,test));
    }
}
