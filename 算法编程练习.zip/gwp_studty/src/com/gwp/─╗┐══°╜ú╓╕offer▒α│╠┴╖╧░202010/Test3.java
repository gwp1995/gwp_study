package com.gwp.幕客网剑指offer编程练习202010;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/10/9
 * Description:
 */

public class Test3 {

    public static void main(String [] args){
        int[] ttt = {1,2,3,4,5,6};
        Scanner scanner = new Scanner(System.in);
        String ss = scanner.nextLine();

        String tt =  ss.replace(" ","%20");
        System.out.println(tt);
    }
}
