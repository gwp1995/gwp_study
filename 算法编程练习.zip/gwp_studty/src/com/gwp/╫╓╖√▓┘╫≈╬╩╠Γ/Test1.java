package com.gwp.字符操作问题;

import java.nio.file.FileStore;
import java.util.HashMap;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/12/26
 * Description: 在一个字符串中找到第一个只出现一次的字符，并返回它的位置。如果没有则返回-1
 */

public class Test1 {
    public static int Firstnotrepeatingchar(String str){
        char[] arr = str.toCharArray();
        char result = ' ';
        HashMap<Character, Integer>  hashMap = new HashMap<>();
        for (int i=0;i<arr.length;i++){
            if (hashMap.containsKey(arr[i])){
                hashMap.put(arr[i],hashMap.get(arr[i])+1);
            }else{
                hashMap.put(arr[i],1);
            }
        }
        for (HashMap.Entry<Character,Integer> map:hashMap.entrySet()) {
            if (map.getValue() == 1){
                result = map.getKey();
                break;
            }
        }
        for (int j=0;j<arr.length;j++){
            if (arr[j] == result){
                return j;
            }
        }
        return -1;
    }
    public static void main(String [] args){
        String test = "google";
        int result = Firstnotrepeatingchar(test);
        System.out.println(result);
    }
}
