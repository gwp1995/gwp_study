package com.gwp.字符操作问题;

import java.util.Scanner;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2021/1/13
 * Description:  将一个字符串转换成首字母大写，其他小写
 */

public class Test3 {
    public static void main(String [] args){
        Scanner scanner = new Scanner(System.in);
        String str = scanner.nextLine();
        String  txt = str.substring(0,1).toUpperCase().concat(str.substring(1).toLowerCase());
        System.out.println(txt);
    }
}
