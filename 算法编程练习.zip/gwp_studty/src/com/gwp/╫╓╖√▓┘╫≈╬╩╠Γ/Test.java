package com.gwp.字符操作问题;



/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/10/31
 * Description: 回文整数判断412214
 */

public class Test {
    //整数回文
    public static Boolean ishuiwen(int target){
        if (target < 0 || (target % 10 ==0 && target != 0))
            return false;
        int tmp=0;
        while (tmp <  target){
            tmp = tmp*10 + target%10;
            target = target / 10;
        }
        return tmp == target || tmp/10 == target;
    }
    //字符回文  调用stringbuffer 中的reverse反转函数即可

    public static void main(String [] args){
        int test = 41214;
//        String tt = "aaabbb";
//        String yy = new StringBuffer(tt).reverse().toString();
//        System.out.println(yy);
        Boolean result = ishuiwen(test);
        System.out.println(result);

    }
}
