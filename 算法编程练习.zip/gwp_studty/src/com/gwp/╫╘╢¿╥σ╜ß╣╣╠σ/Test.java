package com.gwp.自定义结构体;

import java.util.*;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2021/1/18
 * Description: 设置一个数据结构，实现插入、删除、随机取一个元素的时间复杂度为O(1)
 *              想法 数组 + hash表       list + map
 */

class Randomzedset{
    List<Integer> list;
    Map<Integer,Integer> map;
    Random random;

    public Randomzedset(){
        list = new ArrayList<>();
        map = new HashMap<>();
        random = new Random();
    }
    public boolean insert(int val){
        if (map.containsKey(val)){
            return false;
        }
        map.put(val,list.size());
        list.add(val);
         return true;
    }
    public boolean remove(int val){
        if (!map.containsKey(val)){
            return false;
        }
        int temp = list.get(list.size()-1);
        int index = map.get(val);
        list.set(index,temp);
        map.put(temp,index);
        list.remove(list.size()-1);
        map.remove(val);
        return true;
    }
    public int getrandom(){
        return list.get(random.nextInt(list.size()));
    }
}

public class Test {
  public static void main(String [] args){
//      List<Integer> list = new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9));
//      System.out.println(list.get(list.size()-1));
      Randomzedset randomzedset = new Randomzedset();
      randomzedset.insert(1);
      randomzedset.insert(2);
      randomzedset.insert(3);
      System.out.println(randomzedset.getrandom());

  }
}
