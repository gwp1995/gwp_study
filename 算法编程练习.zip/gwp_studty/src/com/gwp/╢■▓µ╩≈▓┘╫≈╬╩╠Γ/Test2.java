package com.gwp.二叉树操作问题;





import java.util.ArrayList;
import java.util.LinkedList;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/13
 * Description: 层次打印二叉树的每个节点
 */

public class Test2 {
    public static ArrayList<Integer> printtree(TreeNode root){
        ArrayList<Integer> result = new ArrayList<>();
        LinkedList<TreeNode> list = new LinkedList();
        list.add(root);
        while (!list.isEmpty()){
             root = list.poll();
             result.add(root.val);
            System.out.println(root.val);
            if (root.left != null){
                list.add(root.left);
            }
            if (root.right != null){
                list.add(root.right);
            }
        }
       return result;
    }
    public static void main(String [] args){
        TreeNode t = new TreeNode(5);
        TreeNode t1 = new TreeNode(4);
        t.left = t1;
        TreeNode t2 = new TreeNode(3);
        t1.left = t2;
        TreeNode t3 = new TreeNode(2);
        t2.left = t3;
        TreeNode t4 = new TreeNode(1);
        t3.left = t4;
        ArrayList<Integer> test =  printtree(t);
//        ArrayList<Integer> yy =  (ArrayList<Integer>) test.clone();
//        System.out.println(yy);
        System.out.println(test);
    }
}
