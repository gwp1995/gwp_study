package com.gwp.二叉树操作问题;

import java.util.ArrayList;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/19
 * Description: 输入一颗二叉树，将该二叉树装换成一个排序的双向链表。要求不能创建任何新的节点。
 */

public class Test4 {
    public static TreeNode convert(TreeNode root){
        if (root == null ) return null;
        ArrayList<TreeNode> list = new ArrayList<>();
        print(root,list);
        for (int i=0;i<list.size()-1;i++){
            list.get(i).right = list.get(i+1);
            list.get(i+1).left = list.get(i);
        }
        return list.get(0);
    }
    public static void print(TreeNode node,ArrayList<TreeNode> list){
        if (node == null) return ;
        if (node.left != null){
            print(node.left,list);
        }
        list.add(node);
        if (node.right != null){
            print(node.right,list);
        }
    }
}
