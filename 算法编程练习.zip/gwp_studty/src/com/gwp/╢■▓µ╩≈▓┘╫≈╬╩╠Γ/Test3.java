package com.gwp.二叉树操作问题;

import javafx.beans.binding.ObjectExpression;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/16
 * Description: 输入一棵二叉树和一个整数，按字典顺序打印二叉树节值的和为整数的所有路径，路径定义从根节点到叶子节点。
 */

public class Test3 {
    private ArrayList<ArrayList<Integer>> res = new ArrayList<>();
    ArrayList<Integer> list = new ArrayList<>();
    public  ArrayList<ArrayList<Integer>> Findpath(TreeNode root,int target){
        if (root == null || target < 0) return res;
        list.add(root.val);
        target = target - root.val;
        if (target == 0 && root.left == null && root.right == null){
            res.add(new ArrayList<>(list));
        }
        Findpath(root.left,target);
        Findpath(root.right,target);
        list.remove(list.size()-1);
        return res;
    }
    public static void main(String [] args){
        TreeNode t = new TreeNode(10);
        TreeNode t1 = new TreeNode(5);
        t.left = t1;
        TreeNode t2 = new TreeNode(12);
        t.right = t2;
        TreeNode t11 = new TreeNode(4);
        TreeNode t12 = new TreeNode(7);
        t1.left = t11;
        t1.right = t12;
        int target = 22;
        Test3 test3 = new Test3();
        ArrayList<ArrayList<Integer>> test  = test3.Findpath(t,target);
        System.out.println(test);
//        HashMap<Object, Object> objectObjectHashMap = new HashMap<>();
//        ConcurrentHashMap<Object, ObjectExpression>  map =  new ConcurrentHashMap<>();
//        Hashtable<Object, Object> objectObjectHashtable = new Hashtable<>();
    }
}
