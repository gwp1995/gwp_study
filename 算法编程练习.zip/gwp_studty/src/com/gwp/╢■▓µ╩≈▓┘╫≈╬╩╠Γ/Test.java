package com.gwp.二叉树操作问题;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/9
 * Description: 判断二棵二叉树 a，b。 b是否是a的子树。 其中空数不是任意一个数的子结构
 */

class TreeNode{
    int val = 0;
    TreeNode left = null;
    TreeNode right = null;
    public TreeNode(int val){
        this.val = val;
    }
}
public class Test {
    public static Boolean hashsubtree(TreeNode root1,TreeNode root2){
        Boolean result = false;
        if (root1 != null && root2 != null){
            if (root1.val == root2.val){
                 result = doesTree1haveTree2(root1,root2);
            }
            if (!result){
                System.out.println("进入左子树");
                result = hashsubtree(root1.left,root2);
            }
            if (!result){
                System.out.println("进入右子树");
                result =  hashsubtree(root1.right,root2);
            }
        }
        return result;
    }
    //根节点相同，和依次遍历子节点 ,若a为空则返回false，如b为空则返回true 后面依次对比2个节点的左右子树值。
    public  static Boolean doesTree1haveTree2(TreeNode node1,TreeNode node2){
        if (node2 == null){
            return  true;
        }
        if (node1 == null){
            return false;
        }
        if (node1.val != node2.val){
            return false;
        }
        return doesTree1haveTree2(node1.left,node2.left) && doesTree1haveTree2(node1.right,node2.right);
    }
    public static void main(String [] args){
        TreeNode t = new TreeNode(8);
        TreeNode t1 = new TreeNode(8);
        t.right = t1;
        TreeNode t2 = new TreeNode(9);
        t1.right = t2;
        TreeNode t3 = new TreeNode(2);
        t2.right = t3;
        TreeNode t4 = new TreeNode(5);
        t3.right = t4;

        TreeNode tt = new TreeNode(8);
        TreeNode tt1 = new TreeNode(9);
        tt.right=tt1;
        TreeNode tt2 = new TreeNode(2);
        tt1.right = tt2;
        System.out.println(hashsubtree(t,tt));
    }
}
