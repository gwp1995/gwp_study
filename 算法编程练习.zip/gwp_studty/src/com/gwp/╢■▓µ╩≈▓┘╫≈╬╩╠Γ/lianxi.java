package com.gwp.二叉树操作问题;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/19
 * Description: 给定2棵树，如果某个节点的子节点数量一样，则打印出来
 */

class NomalTreeNode{
    int val;
    List<NomalTreeNode> child;
    NomalTreeNode(int val){
        this.val = val;
    }
}
public class lianxi {
    HashMap<Integer,Integer> map = new HashMap<>();
    ArrayList<Integer> result = new ArrayList<>();
    public static void  comparison(NomalTreeNode node1,NomalTreeNode node2){
        if (node1 == null || node2 == null) return;

    }
    public  void  prin(NomalTreeNode root){
        List<NomalTreeNode> list = new ArrayList<>();
        if (root == null) return;
        if (root.child == null) result.add(root.val);
        if (root != null && root.child !=null){
            System.out.println("进入循环！！！");
            result.add(root.val);
            if (root.child.size()>0){
                map.put(root.val,root.child.size());
                list.addAll(root.child);
                for (int i=0;i<root.child.size();i++){
                    prin(list.get(i));
                }
            }else{
                map.put(root.val,0);
            }
//            System.out.println(list.size());

        }
//        System.out.println(result);
    }
    public static void main(String [] args){
        NomalTreeNode t = new NomalTreeNode(2);
        NomalTreeNode t1 = new NomalTreeNode(1);
        NomalTreeNode t2 = new NomalTreeNode(3);
        List<NomalTreeNode> list = new ArrayList<>();
        List<NomalTreeNode> list1 = new ArrayList<>();
        List<NomalTreeNode> list2 = new ArrayList<>();
        list.add(t1);
        list.add(t2);
        t.child = list;
        NomalTreeNode t11 = new NomalTreeNode(4);
        list1.add(t11);
        t1.child = list1;
        NomalTreeNode t21 = new NomalTreeNode(5);
        NomalTreeNode t22 = new NomalTreeNode(6);
        NomalTreeNode t23 = new NomalTreeNode(7);
        list2.add(t21);
        list2.add(t22);
        list2.add(t23);
        t2.child = list2;
        lianxi test = new lianxi();
        test.prin(t);
        for( HashMap.Entry<Integer,Integer> tt: test.map.entrySet()) {
            System.out.println(tt);
        }
        System.out.println(test.result);
    }
}
