package com.gwp.二叉树操作问题;

/**
 * @Author: Ge WanPeng
 * @Date: Create in  2020/11/10
 * Description: 求一棵二叉树的镜像树
 */

public class Test1 {
    public static void  Mirror(TreeNode root){
        if (root == null) return;
        TreeNode temp = root.left;
        root.left = root.right;
        root.right = temp;
        if (root.left != null){
            Mirror(root.left);
        }
        if (root.right != null){
            Mirror(root.right);
        }
    }
    public static void  printtree(TreeNode node){
        if (node == null) return;
        System.out.println(node.val);
        printtree(node.left);
        printtree(node.right);
    }
    public static void main(String [] args){
        TreeNode t = new TreeNode(8);
        TreeNode t1 = new TreeNode(6);
        TreeNode t2 = new TreeNode(10);
        t.left =t1;
        t.right = t2;
        TreeNode t11 = new TreeNode(5);
        TreeNode t12 = new TreeNode(7);
        t1.left = t11;
        t1.right = t12;
        TreeNode t21 = new TreeNode(9);
        TreeNode t22 = new TreeNode(11);
        t2.left = t21;
        t2.right = t22;
        Mirror(t);
        printtree(t);
    }
}
