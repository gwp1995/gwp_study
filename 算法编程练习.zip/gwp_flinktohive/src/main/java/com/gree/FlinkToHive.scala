package com.gree


import java.time.Duration

import org.apache.flink.streaming.api.{CheckpointingMode, TimeCharacteristic}
import org.apache.flink.streaming.api.environment.ExecutionCheckpointingOptions
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.table.api.{EnvironmentSettings, SqlDialect}
import org.apache.flink.table.api.bridge.scala.StreamTableEnvironment
import org.apache.flink.table.catalog.hive.HiveCatalog
import org.slf4j.LoggerFactory





/**
  * @Author: Ge WanPeng
  * @Date: Create in  2020/7/30
  *        Description: flink1.11版本 流批一体写入hive测试
  */

object FlinkToHive {
  def main(args: Array[String]): Unit = {

    val Logger = LoggerFactory.getLogger(FlinkToHive.getClass)
    val streamEnv = StreamExecutionEnvironment.getExecutionEnvironment

    streamEnv.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
    streamEnv.setParallelism(1)

    //设置流试table操作环境参数
    val tableEnvSettings = EnvironmentSettings.newInstance()
      .useBlinkPlanner()
      .inStreamingMode()
      .build()

    val tableEnv = StreamTableEnvironment.create(streamEnv,tableEnvSettings)
    tableEnv.getConfig.getConfiguration.set(ExecutionCheckpointingOptions.CHECKPOINTING_MODE, CheckpointingMode.EXACTLY_ONCE)
    tableEnv.getConfig.getConfiguration.set(ExecutionCheckpointingOptions.CHECKPOINTING_INTERVAL,Duration.ofSeconds(20))

    //注册hive Catalog
    val catalogname = "myhive"
    val catalog = new HiveCatalog(
      catalogname,
      "hive_test",
      "F:\\hive相关文件\\",
      "2.1.1"
    )

    tableEnv.registerCatalog(catalogname,catalog)
    tableEnv.useCatalog(catalogname)


    //创建kafka流表
    tableEnv.getConfig.setSqlDialect(SqlDialect.DEFAULT)
    tableEnv.executeSql("create database if not exists stream_tmp")
    tableEnv.executeSql("drop table if exists stream_tmp.kafka_table")
    tableEnv.executeSql(
      """
        |create table stream_tmp.kafka_table(
        | id string,
        | pgid string,
        | `table` string,
        | ts bigint,
        | procTime AS PROCTIME(),
        | eventTime AS TO_TIMESTAMP(FROM_UNIXTIME(ts / 1000 ,'yyyy-MM-dd HH:mm:ss')),
        | WATERMARK FOR eventTime AS eventTime - INTERVAL '15' SECOND
        |) WITH (
        | 'connector' = 'kafka',
        | 'topic' = 'WxData-T2',
        | 'properties.bootstrap.servers' = '10.2.11.213:9092,10.2.11.214:9092,10.2.11.215:9092',
        | 'properties.group.id' = 'flink_hive_1',
        | 'scan.startup.mode' = 'latest-offset',
        | 'format' = 'json',
        | 'json.fail-on-missing-field' = 'false',
        | 'json.ignore-parse-errors' = 'true'
        |)
      """.stripMargin
    )

    //创建hive表
    //flink sql 提供了兼容hiveql风格的ddl，指定sqldialect为hive即可
    tableEnv.getConfig.setSqlDialect(SqlDialect.HIVE)
    tableEnv.executeSql("create database if not exists hive_tmp")
    tableEnv.executeSql("drop table if exists hive_tmp.access_hive")
    tableEnv.executeSql(
      """
        | create table hive_tmp.access_hive(
        | id string,
        | pgid string,
        | tablename string,
        | ts bigint
        | )  partitioned by (
        | table_name string
        | ) stored as parquet
        | tblproperties(
        | 'sink.partition-commit.policy.kind' = 'metastore,success-file'
        | )
      """.stripMargin
    )

    //流试写入hive
    tableEnv.getConfig.setSqlDialect(SqlDialect.DEFAULT)
    tableEnv.executeSql(
      """
        | insert into hive_tmp.access_hive
        | select
        | id,pgid,`table`,ts,`table` as table_name
        | from stream_tmp.kafka_table
      """.stripMargin
    )


    streamEnv.execute("flink结合hive流批一体")
  }

}
