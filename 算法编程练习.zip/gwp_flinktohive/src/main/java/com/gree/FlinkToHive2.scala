package com.gree

import java.time.Duration

import org.apache.flink.streaming.api.{CheckpointingMode, TimeCharacteristic}
import org.apache.flink.streaming.api.environment.ExecutionCheckpointingOptions
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.table.api.{EnvironmentSettings, SqlDialect}
import org.apache.flink.table.api.bridge.scala.StreamTableEnvironment
import org.apache.flink.table.catalog.hive.HiveCatalog
import org.slf4j.LoggerFactory

/**
  * @Author: Ge WanPeng
  * @Date: Create in  2020/8/13
  *        Description:
  */

object FlinkToHive2 {
  def main(args: Array[String]): Unit = {
    val Logger = LoggerFactory.getLogger(FlinkToHive.getClass)
    val streamEnv = StreamExecutionEnvironment.getExecutionEnvironment

    streamEnv.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
    streamEnv.setParallelism(1)


    //设置流试table操作环境参数
    val tableEnvSettings = EnvironmentSettings.newInstance()
      .useBlinkPlanner()
      .inStreamingMode()
      .build()

    val tableEnv = StreamTableEnvironment.create(streamEnv,tableEnvSettings)
    tableEnv.getConfig.getConfiguration.set(ExecutionCheckpointingOptions.CHECKPOINTING_MODE, CheckpointingMode.EXACTLY_ONCE)
    tableEnv.getConfig.getConfiguration.set(ExecutionCheckpointingOptions.CHECKPOINTING_INTERVAL,Duration.ofSeconds(20))


    //注册hive Catalog
    val catalogname = "myhive"
    val catalog = new HiveCatalog(
      catalogname,
      "hive_test",
      "F:\\hive相关文件\\",
      "2.1.1"
    )

    tableEnv.registerCatalog(catalogname,catalog)
    tableEnv.useCatalog(catalogname)


    //创建kafka流表
    tableEnv.getConfig.setSqlDialect(SqlDialect.DEFAULT)
    tableEnv.executeSql("create database if not exists stream_tmp")
    tableEnv.executeSql("drop table if exists stream_tmp.kafka_table1")
    tableEnv.executeSql(
      """
        | create table stream_tmp.kafka_table1(
        | `table` string,
        | ts  bigint,
        | data ARRAY<ROW(id string, created_by string, created_date timestamp, last_modified_by string, last_modified_date timestamp, kssj timestamp
        | ,jssj timestamp, czren string, pgid string, czsj timestamp, leix string, reason string, beiz string)>,
        | eventTime AS TO_TIMESTAMP(FROM_UNIXTIME(ts / 1000 ,'yyyy-MM-dd HH:mm:ss')),
        | WATERMARK FOR eventTime AS eventTime - INTERVAL '10' SECOND
        | ) WITH (
        | 'connector' = 'kafka',
        | 'topic' = 'app_greeshservice.tbl_assign_appointment',
        | 'properties.bootstrap.servers' = '10.2.11.213:9092,10.2.11.214:9092,10.2.11.215:9092',
        | 'properties.group.id' = 'flink_hive_1',
        | 'scan.startup.mode' = 'earliest-offset',
        | 'json.fail-on-missing-field' = 'false',
        | 'json.ignore-parse-errors' = 'true',
        | 'format' = 'json'
        |)
      """.stripMargin
    )
    //创建hive表
    //flink sql 提供了兼容hiveql风格的ddl，指定sqldialect为hive即可
    tableEnv.getConfig.setSqlDialect(SqlDialect.HIVE)
    tableEnv.executeSql("create database if not exists hive_tmp")
    tableEnv.executeSql("drop table if exists hive_tmp.kafka_hive")
    tableEnv.executeSql(
      """
        | create table hive_tmp.kafka_hive (
        | tablename string,
        | ts bigint,
        | id string,
        | created_by string,
        | created_date timestamp,
        | last_modified_by string,
        | last_modified_date timestamp,
        | kssj timestamp,
        | jssj timestamp,
        | czren string,
        | pgid string,
        | czsj timestamp,
        | leix string,
        | reason string,
        | beiz string
        | )partitioned by(
        | ts_data string,ts_hour string
        | )stored as parquet
        | tblproperties(
        | 'sink.partition-commit.policy.kind' = 'metastore,success-file',
        |  'sink.partition-commit.trigger' = 'partition-time',
        |  'sink.partition-commit.delay' = '1 h',
        |  'partition.time-extractor.timestamp-pattern' = '$ts_date $ts_hour:00:00'
        | )
      """.stripMargin
    )

    //流试写入hive
    tableEnv.getConfig.setSqlDialect(SqlDialect.DEFAULT)
    tableEnv.executeSql(
      """
        | insert into hive_tmp.kafka_hive
        | select `table`, ts, data[1].id, data[1].created_by, data[1].created_date, data[1].last_modified_by
        | , data[1].last_modified_date, data[1].kssj, data[1].jssj, data[1].czren, data[1].pgid, data[1].czsj
        | , data[1].leix, data[1].reason, data[1].beiz, date_format(eventTime ,'yyyy-MM-dd'),date_format(eventTime,'HH')
        | from stream_tmp.kafka_table1
      """.stripMargin
    )

    val result = tableEnv.executeSql("select * from hive_tmp.kafka_hive limit 10")
    result.print()

    streamEnv.execute("解析复杂josn数据写入hive")
  }
}
