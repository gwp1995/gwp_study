package com.gree

import java.time.Duration

import com.gree.model.TrueData
import org.apache.flink.streaming.api.environment.ExecutionCheckpointingOptions
import org.apache.flink.streaming.api.{CheckpointingMode, TimeCharacteristic}
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.table.api.{EnvironmentSettings, SqlDialect}
import org.apache.flink.table.api.bridge.scala.StreamTableEnvironment
import org.apache.flink.table.catalog.hive.HiveCatalog
import org.slf4j.LoggerFactory
import org.apache.flink.api.scala._
import org.apache.flink.types.Row

/**
  * @Author: Ge WanPeng
  * @Date: Create in  2020/8/20
  *        Description:
  */

object FlinkSqlAndProcess {
  def main(args: Array[String]): Unit = {
    val Logger = LoggerFactory.getLogger(FlinkSqlAndProcess.getClass)
    val streamEnv = StreamExecutionEnvironment.getExecutionEnvironment


    streamEnv.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
    streamEnv.setParallelism(1)

    //设置流试table操作环境参数
    val tableEnvSettings = EnvironmentSettings
      .newInstance()
      .useBlinkPlanner()
      .inStreamingMode()
      .build()

    val tableEnv = StreamTableEnvironment.create(streamEnv,tableEnvSettings)
    tableEnv.getConfig.getConfiguration.set(ExecutionCheckpointingOptions.CHECKPOINTING_MODE, CheckpointingMode.EXACTLY_ONCE)
    tableEnv.getConfig.getConfiguration.set(ExecutionCheckpointingOptions.CHECKPOINTING_INTERVAL,Duration.ofSeconds(20))

    //注册hive Catalog
//    val catalogname = "myhive"
//    val catalog = new HiveCatalog(
//      catalogname,
//      "hive_test",
//      "F:\\hive相关文件\\",
//      "2.1.1"
//    )
//
//    tableEnv.registerCatalog(catalogname,catalog)
//    tableEnv.useCatalog(catalogname)


    //创建kafka流表
//    tableEnv.getConfig.setSqlDialect(SqlDialect.DEFAULT)
//    tableEnv.executeSql("create database if not exists stream_tmp")
//    tableEnv.executeSql("drop table if exists stream_tmp.kafka_table")
    //DDL语言
//    val sourceDDL:String = ""+
//        "create table kafka_table " +
//        "(" +
//        "id string," +
//        "pgid string," +
//        "`table` string," +
//        "ts bigint," +
//        "proctime AS PROCTIME()" +
//        ")with(" +
//        " 'connector' = 'kafka'," +
//        " 'topic' = 'WxData-T2', " +
//        " 'properties.bootstrap.servers' = '10.2.11.213:9092,10.2.11.214:9092,10.2.11.215:9092', " +
//        " 'properties.group.id' = 'flink_hive_1', " +
//        " 'scan.startup.mode' = 'earliest-offset' , " +
//        " 'format' = 'json', " +
//        " 'json.fail-on-missing-field' = 'false', " +
//        " 'json.ignore-parse-errors' = 'true' " +
//        " )"
    tableEnv.sqlUpdate(
      """
        |create table kafka_table(
        | id string,
        | pgid string,
        | `table` string,
        | ts bigint,
        | proctime AS PROCTIME(),
        | eventTime AS TO_TIMESTAMP(FROM_UNIXTIME(ts / 1000 ,'yyyy-MM-dd HH:mm:ss')),
        | WATERMARK FOR eventTime AS eventTime - INTERVAL '2' SECOND
        |) WITH (
        | 'connector' = 'kafka',
        | 'topic' = 'WxData-T2',
        | 'properties.bootstrap.servers' = '10.2.11.213:9092,10.2.11.214:9092,10.2.11.215:9092',
        | 'properties.group.id' = 'flink_hive_1',
        | 'scan.startup.mode' = 'earliest-offset',
        | 'format' = 'json',
        | 'json.fail-on-missing-field' = 'false',
        | 'json.ignore-parse-errors' = 'true'
        |)
      """.stripMargin
    )
//    tableEnv.sqlUpdate(sourceDDL)

    val result = tableEnv.sqlQuery(
      "select aa.id,aa.pgid,aa.tablename,aa.ts from ( select id, pgid,`table` as tablename,ts, row_number() " +
        "over(partition by pgid order by ts desc) as r " +
        "from kafka_table ) aa where aa.r =1 "
    )

    val test = tableEnv.sqlQuery(
      "select pgig from kafka_table group by  TUMBLE(proctime, INTERVAL '3' SECOND),pgid"
    )

    tableEnv.toRetractStream[TrueData](result)
//      .filter(_._1 == true)
//      .map(_._2)
      .print("开窗函数去重结果----->")
//    while(result.collect().hasNext){
//      val data = result.collect().next()
//      val TestData:TrueData = TrueData(data.getField(0).toString,data.getField(1).toString,
//        data.getField(2).toString,data.getField(3).toString)
//
//        Logger.info("id: "+TestData.id+" pgid: "+TestData.pgid+" table: "+TestData.table+" ts:" + TestData.ts)
//    }
//    tableEnv.execute("ttttttttttttt")

    streamEnv.execute("flink process 结合 sql 开发")
  }

}
